# Bloom 账本工作台｜运行与验收手册

面向交付验收：如何在本地启动 ReproCheck、进入 Bloom 账本、复现已验证的交互，以及当前边界。

- 设计规范：[`BLOOM_UI_DESIGN.md`](./BLOOM_UI_DESIGN.md)
- 任务定位：把项目工作台从"矩形卡片 + 表格 + 固定网格"改为可独立运动、逐层绽放、联动让位、可组合的非矩形卡片舞台；不新增动画依赖，不改变既有路由、接口、权限与数据。

## 1. 环境要求

- Windows 11（当前验证环境）或任意可运行 Python 3.10+ / Node.js 18+ 的系统。
- 后端依赖已安装在 `backend/.venv`；前端依赖已安装在 `frontend/node_modules`。
- 浏览器：Chrome / Edge（需要支持 `clip-path: polygon()` 与 CSS 3D transform）。
- 不需要 GPU；真实代码执行默认关闭（`execution_backend=none`）。

## 2. 启动

### 2.1 后端（终端 1）

```powershell
cd C:\Users\ASUS\Desktop\科研复现审计官\backend
.\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

健康检查：

```powershell
Invoke-RestMethod http://127.0.0.1:8000/api/v1/health
```

期望返回包含 `version` 的 JSON；接口文档在 `http://127.0.0.1:8000/docs`。

### 2.2 前端（终端 2）

```powershell
cd C:\Users\ASUS\Desktop\科研复现审计官\frontend
npm install
npm run dev -- --host 127.0.0.1 --port 5173
```

- 前端：`http://127.0.0.1:5173/`
- Vite 将 `^/api/` 代理到 `http://localhost:8000`，因此后端必须先在 8000 端口运行。

### 2.3 演示账号

```text
邮箱：lead@reprocheck.demo
密码：ReproCheck#2026
```

登录后 token 写入 `localStorage` 的 `rc_token`；页面刷新仍保持登录。

## 3. 进入 Bloom 账本

直达演示项目工作台：

```text
http://127.0.0.1:5173/projects/proj-209c77cd39f94212/workbench
```

四个既有页面均提供入口：

- **Dashboard（`/`）**：最近项目区的"项目星丛"，点击纸瓣进入。
- **Projects（`/projects`）**：列表"项目账本"列的「Bloom 账本」。
- **Overview（`/projects/{id}/overview`）**：页头「Bloom 账本」按钮。
- **ReproductionOverview（`/projects/{id}/reproduction`）**：页头「Bloom 账本」按钮。

深链恢复单卡：

```text
http://127.0.0.1:5173/projects/proj-209c77cd39f94212/workbench?focus=materials
```

## 4. 已验证操作（2026-11-21）

### 4.1 桌面 1440×900

1. 打开工作台，10 张瓣卡分布在三条轨道，无重叠、无标题裁切；中央核显示真实质量分 `0.545`。
2. 点击「论文与材料」：瓣卡在 680ms 内形变为 1080×640 档案页，显示 2 份材料、2 个解析任务、12 条事实、解析覆盖。
3. URL 变为 `?focus=materials`；按 `Esc` 收拢，URL 清除，焦点回到材料卡。
4. 展开页头部点 `⊕`，底部出现"选择第二片瓣"胶囊；点击「科研事实」。
5. 组合页标题为「论文与材料 × 科研事实」，双栏均为真实数据；底栏「打开材料管理 / 打开科研事实」可点击。
6. 按 `Esc` 从组合拆回单卡展开；再按 `Esc` 回到收拢态。
7. 收拢态拖动空白可旋转轨道 ±7°；拖超过 5px 不会误触"空白关闭"。

### 4.2 窄桌面 1024×768

1. 展开面板自适应为 874×532，内容区独立滚动，底栏 101px 不压正文。
2. 组合面板 874×532，双栏 314px，底栏两个按钮完整可见。
3. 侧卡会与面板边缘部分重叠，作为层次背景；主内容与按钮不被遮挡。

### 4.3 移动端 390×844

1. 页面进入 `bloom-page--mobile`：页头只保留项目名与返回，中心核、轨道线、阶段脊、底栏隐藏。
2. 10 张卡纵向排列，单卡 362×104，标题与指标横排，不再被瓣形裁切。
3. 点击卡片：固定定位全屏工作区，四周 8px、圆角 22px、`clip-path: none`；底栏按钮可见、内容可滚动。
4. 展开页点 `⊕`：底部 `.bloom-picker` 列出其余 9 个单元；选「科研事实」进入单列组合面板。
5. `Esc` 或 `×` 返回列表，焦点回到原卡。

### 4.4 键盘与可访问性

- `Tab` 聚焦瓣卡，`Enter` / `Space` 展开。
- `Esc` 逐层回退：组合 → 单卡 → 列表。
- 收拢卡带 `aria-expanded` / `aria-controls`；展开区为 `role="region"`。
- `prefers-reduced-motion: reduce` 时所有过渡压到 1ms，功能不变。

## 5. 构建与静态检查

```powershell
cd C:\Users\ASUS\Desktop\科研复现审计官\frontend
npm run typecheck
npm run build
```

当前结果：`typecheck` 退出码 0；`vite build` 成功，1716 modules transformed，产物在 `frontend/dist/`。仅保留 Vite 的 chunk > 500kB 体积提示；未引入 framer-motion、GSAP、Three.js 等新依赖。

## 6. 关键文件

```text
frontend/src/bloom/
├── geometry.ts            轮廓、轨道、面板盒
├── motion.ts              缓动与时长
├── types.ts               单元与状态类型
├── useBloomLayout.ts      响应式布局
├── unitIcons.ts           图标映射
├── unitDetailParts.tsx    数据 hooks 与通用块
├── unitDetails.tsx        10 个真实详情面板
├── useBloomUnits.ts       摘要编排与组合洞察
├── BloomCard.tsx          瓣卡 / 展开工作区
├── BloomStage.tsx         舞台 / 连线 / 移动选择器
├── BloomWorkbench.tsx     状态机 / URL / 键盘
├── ProjectConstellation.tsx 首页星丛
└── bloom.css              约 1800 行，`.bloom-*` 命名空间
```

页面接入：

- `frontend/src/pages/ProjectWorkbenchPage.tsx`（工作台路由页）
- `frontend/src/App.tsx`（`projects/:projectId/workbench`）
- `frontend/src/components/AppLayout.tsx`（Bloom 沉浸分支）
- `frontend/src/pages/DashboardPage.tsx`、`ProjectsPage.tsx`、`OverviewPage.tsx`、`reproduction/ReproductionOverviewPage.tsx`（四个入口）

真实数据采样：项目根 `.bloom-sample.json`。后端临时检查脚本 `backend/_inspect.py` 不参与运行，可删除。

## 7. 数据口径（演示项目 `proj-209c77cd39f94212`）

- 材料 2；解析任务 2（均完成）；事实 12（有证据 12、待复核 0、人工确认 1）。
- 证据图谱：事实 12、证据 12、材料 1、原文块 2、关系边 36。
- 规划 1（5 个任务，feasible 4 / needs_human_review 1 / blocked 0）。
- 环境 1（Python 3.8.10、PyTorch 1.8.0、torchvision 0.9.0、8×V100/32GB、缺失随机种子与数据增强版本）。
- 运行 2：`completed` 1（221400000ms）、`failed` 1（CUDA OOM 2.00GiB/31.75GiB）。
- 指标对照 4：within_tolerance 2、not_comparable 1、insufficient_data 1。
- 质量分 0.545；结论 VERIFIED 13 / INSUFFICIENT_EVIDENCE 1 / UNVERIFIABLE 2。
- 报告 1（`rreport-8ad153c3c8e44e`，14 章，final v1，HTML 可用、PDF 不可用）；成员 4。
- 数据审计 0 条：卡片显示真实空态，不伪造记录。

## 8. 常见问题

**页面 401 / 登录失效**
重新登录演示账号；确认 `localStorage` 中 `rc_token` 存在。

**前端请求 404 / 502**
先确认 `http://127.0.0.1:8000/api/v1/health` 可访问；Vite 代理只匹配 `^/api/`。

**移动端样式未生效**
用 DevTools 设备模拟 390×844，并刷新页面；`mobile` 由 `ResizeObserver` 测量 `.bloom-stage` 宽度决定，断点为 900px。

**修改 CSS 后视觉未更新**
Vite HMR 偶尔保留旧的 hover 状态；移开鼠标或刷新页面再看。

**控制台提示 React Router future flag**
既有 v6 警告，不影响路由与功能；本次未改动路由版本。

**报告 PDF 按钮不可用**
演示数据 `pdf_available=false`，这是真实后端状态；不要用前端伪造 PDF。

## 9. 交付边界

- 本工作台只读取既有 `/api/v1` 接口，不新增后端接口、不改数据库、不改权限模型。
- 组合是"并置展示 + 真实关联摘要"，不是新的业务对象，不写库。
- 不执行用户代码；运行状态完全来自后端真实记录。
- 900–1100px 宽度下侧卡允许部分被面板遮挡；这是层次表达，不影响主工作区。
- 组合状态不写 URL，避免刷新后出现无法解释的半组合态。

## 10. 视觉证据

- [桌面收拢态](./bloom/bloom-desktop-rest.png)
- [桌面展开态](./bloom/bloom-desktop-open.png)
- [桌面组合态](./bloom/bloom-desktop-combined.png)
- [1024 展开态](./bloom/bloom-tablet-open-1024.png)
- [移动端展开态](./bloom/bloom-mobile-open.png)

截图来自真实运行的演示项目，不是设计稿；面板中的计数、文件名、质量分、缺失项均来自 `/api/v1`。
