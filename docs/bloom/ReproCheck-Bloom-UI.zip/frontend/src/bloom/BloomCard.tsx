import { useEffect, useMemo, useRef, useState } from 'react'
import type { CSSProperties, KeyboardEvent, PointerEvent } from 'react'
import { ArrowUpRight, Plus, X } from 'lucide-react'
import { Link } from 'react-router-dom'
import {
  archivePolygon,
  closedPolygon,
  petalPolygon,
  polygonCss,
  REST_H,
  REST_W,
} from './geometry'
import { entranceDelay } from './motion'
import type { BloomUnit } from './types'
import { UNIT_ICONS } from './unitIcons'
import { UnitDetail } from './unitDetails'
import type { Placement } from './geometry'

type BloomCardProps = {
  unit: BloomUnit
  projectId: string
  placement: Placement
  center: { x: number; y: number }
  open: boolean
  selected: boolean
  combining: boolean
  mobile: boolean
  entered: boolean
  entering: boolean
  dimmed: boolean
  onOpen: () => void
  onSelect: () => void
  onClose: () => void
}

function revealDelay(ms: number): CSSProperties {
  return { '--reveal-delay': `${ms}ms` } as CSSProperties
}

export function BloomCard({
  unit,
  projectId,
  placement,
  center,
  open,
  selected,
  combining,
  mobile,
  entered,
  entering,
  dimmed,
  onOpen,
  onSelect,
  onClose,
}: BloomCardProps) {
  const [hovered, setHovered] = useState(false)
  const [revealed, setRevealed] = useState(false)
  const tiltRef = useRef<HTMLSpanElement | null>(null)

  useEffect(() => {
    if (!open) {
      setRevealed(false)
      return
    }
    let second = 0
    const first = window.requestAnimationFrame(() => {
      second = window.requestAnimationFrame(() => setRevealed(true))
    })
    return () => {
      window.cancelAnimationFrame(first)
      if (second) window.cancelAnimationFrame(second)
    }
  }, [open])

  const restClip = useMemo(
    () => polygonCss(petalPolygon(unit.seed, 48, hovered && !open ? 1.14 : 1)),
    [unit.seed, hovered, open],
  )
  const openClip = useMemo(() => polygonCss(archivePolygon(unit.seed)), [unit.seed])
  const closedClip = useMemo(() => polygonCss(closedPolygon(unit.seed)), [unit.seed])

  const clip = !entered ? closedClip : open ? openClip : restClip
  const Icon = UNIT_ICONS[unit.id]

  const offsetX = placement.x - placement.w / 2
  const offsetY = placement.y - placement.h / 2
  const targetTransform = `translate3d(${offsetX}px, ${offsetY}px, 0) rotate(${placement.rotate}deg) scale(${placement.scale})`
  const initialTransform = `translate3d(${center.x - REST_W / 2}px, ${center.y - REST_H / 2}px, 0) scale(0.42)`

  const style: CSSProperties = {
    width: entered ? placement.w : REST_W,
    height: entered ? placement.h : REST_H,
    transform: entered ? targetTransform : initialTransform,
    opacity: entered ? placement.opacity : 0,
    zIndex: open ? 44 : placement.z,
    '--bloom-delay': entering ? `${entranceDelay(unit.order)}ms` : '0ms',
    '--bloom-clip': clip,
  } as CSSProperties

  const compactClick = () => {
    if (combining) onSelect()
    else onOpen()
  }

  const onCompactKey = (event: KeyboardEvent<HTMLButtonElement>) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault()
      compactClick()
    }
  }

  const onPointerMove = (event: PointerEvent<HTMLSpanElement>) => {
    if (open || mobile || !tiltRef.current) return
    const rect = event.currentTarget.getBoundingClientRect()
    if (rect.width === 0) return
    const dx = (event.clientX - (rect.left + rect.width / 2)) / rect.width
    const dy = (event.clientY - (rect.top + rect.height / 2)) / rect.height
    tiltRef.current.style.transform = `perspective(760px) rotateX(${(-dy * 3.6).toFixed(2)}deg) rotateY(${(dx * 4.6).toFixed(2)}deg)`
  }

  const resetTilt = () => {
    if (tiltRef.current) tiltRef.current.style.transform = ''
    setHovered(false)
  }

  const cardClass = [
    'bloom-card',
    open ? 'is-open' : '',
    open && revealed ? 'is-revealed' : '',
    dimmed && !open ? 'is-dimmed' : '',
    selected ? 'is-selected' : '',
    !open && placement.w < 150 ? 'is-narrow' : '',
  ]
    .filter(Boolean)
    .join(' ')

  return (
    <article
      className={cardClass}
      style={style}
      data-unit={unit.id}
      aria-label={open ? undefined : `${unit.title}，${unit.metric} ${unit.metricLabel}`}
    >
      <span className="bloom-card__surface" onPointerMove={onPointerMove} onPointerLeave={resetTilt}>
        <span className="bloom-card__tilt" ref={tiltRef}>
          <span className="bloom-card__body">
            <button
              type="button"
              className="bloom-compact"
              onClick={compactClick}
              onKeyDown={onCompactKey}
              onPointerEnter={() => setHovered(true)}
              onPointerLeave={() => setHovered(false)}
              aria-expanded={open}
              aria-controls={`bloom-panel-${unit.id}`}
            >
              <span className="bloom-compact__top">
                <span className="bloom-compact__index">{String(unit.order + 1).padStart(2, '0')}</span>
                <span className="bloom-compact__icon" aria-hidden="true">
                  <Icon size={15} strokeWidth={1.9} />
                </span>
              </span>
              <span className="bloom-compact__kicker">{unit.kicker}</span>
              <span className="bloom-compact__title">{unit.title}</span>
              <span className="bloom-compact__hint">
                <span>
                  <span className="bloom-compact__metric">{unit.metric}</span>
                  <span className="bloom-compact__metric-label">{unit.metricLabel}</span>
                </span>
                <span className="bloom-compact__status">
                  <span className={`bloom-dot tone-${unit.tone}`} aria-hidden="true" />
                  {unit.status}
                </span>
              </span>
              <span className="bloom-compact__peek" aria-hidden="true">
                {unit.summary}
              </span>
            </button>

            {open && (
              <div
                className="bloom-detail"
                id={`bloom-panel-${unit.id}`}
                role="region"
                aria-label={`${unit.title}工作区`}
              >
                <div className="bloom-detail__head bloom-reveal" style={revealDelay(0)}>
                  <div className="bloom-detail__heading">
                    <p className="bloom-detail__kicker">
                      {String(unit.order + 1).padStart(2, '0')} · {unit.kicker}
                    </p>
                    <h2 className="bloom-detail__title">{unit.title}</h2>
                    <p className="bloom-detail__sub">{unit.summary}</p>
                  </div>
                  <div className="bloom-detail__tools">
                    <button
                      type="button"
                      className="bloom-icon-btn"
                      title="与其他单元组合"
                      aria-label="与其他单元组合"
                      onClick={onSelect}
                    >
                      <Plus size={15} />
                    </button>
                    {unit.links[0] && (
                      <Link
                        to={unit.links[0].to}
                        className="bloom-icon-btn"
                        title={`在标准视图打开：${unit.links[0].label}`}
                        aria-label={`在标准视图打开：${unit.links[0].label}`}
                      >
                        <ArrowUpRight size={15} />
                      </Link>
                    )}
                    <button
                      type="button"
                      className="bloom-icon-btn"
                      title="收拢"
                      aria-label="收拢"
                      onClick={onClose}
                    >
                      <X size={15} />
                    </button>
                  </div>
                </div>
                <div className="bloom-detail__body">
                  <div className="bloom-detail__scroll" tabIndex={0}>
                    <UnitDetail unitId={unit.id} projectId={projectId} />
                  </div>
                </div>
                <div className="bloom-detail__foot bloom-reveal" style={revealDelay(270)}>
                  {unit.links.map((link) => (
                    <Link
                      key={`${unit.id}-${link.label}`}
                      to={link.to}
                      className={link.label === '打开完整页面' ? 'btn-primary' : 'btn-ghost'}
                    >
                      {link.label}
                      <ArrowUpRight size={13} />
                    </Link>
                  ))}
                  <span style={{ marginLeft: 'auto', fontSize: 10, color: 'rgba(14,15,12,0.42)' }}>
                    数据来自 /api/v1 实时接口
                  </span>
                </div>
              </div>
            )}
          </span>
        </span>
      </span>
    </article>
  )
}
