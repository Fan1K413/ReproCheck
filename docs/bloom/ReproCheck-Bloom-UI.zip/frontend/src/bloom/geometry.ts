/**
 * Bloom UI 几何内核：花瓣 / 档案页轮廓与轨道布局。
 *
 * 所有轮廓都用同一组 48 个归一化控制点（0–100%）表达，
 * 因此 clip-path 的 polygon 可以在任意两个状态之间平滑插值，
 * 卡片形状的变化是真实的结构形变，而不是 scale 缩放。
 */

export type Pt = { x: number; y: number }
export type Ring = 0 | 1 | 2
export type StageBox = { w: number; h: number }

export type CardSpec = {
  id: string
  order: number
  ring: Ring
  angle: number
  seed: number
}

export type Placement = {
  x: number
  y: number
  w: number
  h: number
  rotate: number
  scale: number
  opacity: number
  z: number
}

export type PanelBox = { x: number; y: number; w: number; h: number }

export const CONTOUR_POINTS = 48
export const REST_W = 172
export const REST_H = 126
export const MOBILE_CARD_H = 104
export const MOBILE_TOP = 32

const TAU = Math.PI * 2

/** 确定性伪随机：同一个 seed 在任何设备上生成同一片瓣。 */
function lcg(seed: number): () => number {
  let s = (seed || 1) >>> 0
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0
    return s / 4294967296
  }
}

function wrapAngle(value: number): number {
  let angle = value
  while (angle > Math.PI) angle -= TAU
  while (angle < -Math.PI) angle += TAU
  return angle
}

function round(value: number): number {
  return Math.round(value * 100) / 100
}

/** 收拢态的瓣形：椭圆基底叠加三个低频谐波，形成克制、有生命感的瓣。 */
export function petalPolygon(
  seed: number,
  count = CONTOUR_POINTS,
  spread = 1,
): Pt[] {
  const rand = lcg(seed)
  const a1 = (0.02 + rand() * 0.03) * spread
  const p1 = rand() * TAU
  const a2 = (0.008 + rand() * 0.015) * spread
  const p2 = rand() * TAU
  const a3 = (0.003 + rand() * 0.007) * spread
  const p3 = rand() * TAU
  // 轻微的方向性拉长，让每片瓣看起来是"长出来的"，而不是复制品。
  const stretch = 1 + (rand() - 0.5) * 0.06
  const points: Pt[] = []
  for (let i = 0; i < count; i += 1) {
    const theta = (i / count) * TAU
    const radius =
      1 +
      a1 * Math.cos(2 * theta + p1) +
      a2 * Math.cos(3 * theta + p2) +
      a3 * Math.cos(5 * theta + p3)
    const rx = 46 * radius * stretch
    const ry = 46 * radius
    points.push({
      x: 50 + rx * Math.cos(theta),
      y: 50 + ry * Math.sin(theta),
    })
  }
  return points
}

/**
 * 展开态的"档案页"：超椭圆（圆角矩形感的非矩形）+ 一处缺口 + 一处斜切。
 * 缺口与斜切的位置由 seed 决定，保证每张工作区轮廓不完全相同。
 */
export function archivePolygon(
  seed: number,
  count = CONTOUR_POINTS,
): Pt[] {
  const rand = lcg(seed + 977)
  const notchTheta = (0.3 + rand() * 0.4) * TAU
  const slashTheta = notchTheta + Math.PI * (0.55 + rand() * 0.35)
  const notchDepth = 0.035 + rand() * 0.025
  const notchWidth = 0.14 + rand() * 0.08
  const slashDepth = 0.015 + rand() * 0.015
  const exponent = 8.5 + rand() * 2.5
  const points: Pt[] = []
  for (let i = 0; i < count; i += 1) {
    const theta = (i / count) * TAU
    const cos = Math.abs(Math.cos(theta))
    const sin = Math.abs(Math.sin(theta))
    const superRadius = Math.pow(
      Math.pow(cos, exponent) + Math.pow(sin, exponent),
      -1 / exponent,
    )
    const notch =
      1 -
      notchDepth *
        Math.exp(-Math.pow(wrapAngle(theta - notchTheta), 2) / (2 * notchWidth * notchWidth))
    const slash =
      1 -
      slashDepth *
        Math.exp(
          -Math.pow(wrapAngle(theta - slashTheta), 2) / (2 * 0.055 * 0.055),
        )
    const radius = superRadius * notch * slash
    points.push({
      x: 50 + 46 * radius * Math.cos(theta),
      y: 50 + 46 * radius * Math.sin(theta),
    })
  }
  return points
}

/** CSS polygon 字符串；保留两位小数，减少 inline style 体积。 */
export function polygonCss(points: Pt[]): string {
  return `polygon(${points
    .map((point) => `${round(point.x)}% ${round(point.y)}%`)
    .join(', ')})`
}

/** 供入场动画使用：从中心闭合的小瓣展开到完整瓣形。 */
export function closedPolygon(seed: number): Pt[] {
  const points = petalPolygon(seed, CONTOUR_POINTS, 0.2)
  return points.map((point) => ({
    x: 50 + (point.x - 50) * 0.18,
    y: 50 + (point.y - 50) * 0.18,
  }))
}

/** 默认倾角：-7° ~ +9°，由 seed 固定。 */
export function cardTilt(spec: CardSpec): number {
  const rand = lcg(spec.seed + 41)
  return -7 + rand() * 16
}

/** 中心核半径，桌面 112px，移动端 88px。 */
export function coreRadius(stage: StageBox, mobile: boolean): number {
  return mobile ? 82 : Math.min(118, stage.w * 0.085, stage.h * 0.16)
}

/** 桌面轨道半径的基准值：同时受宽度与高度约束，保证卡片不越界。 */
export function orbitBaseRadius(stage: StageBox): number {
  const byWidth = stage.w / 2 - (REST_W / 2 + 34)
  const byHeight = (stage.h / 2 - (REST_H / 2 + 42)) * 1.55
  return Math.max(190, Math.min(byWidth, byHeight))
}

export function restPlacement(
  stage: StageBox,
  spec: CardSpec,
  mobile: boolean,
  mobileCount: number,
): Placement {
  if (mobile) {
    const w = Math.min(560, stage.w - 28)
    const h = MOBILE_CARD_H
    const step = h + 10
    const total = mobileCount * step
    const start = MOBILE_TOP + Math.max(0, (stage.h - MOBILE_TOP - 64 - total) / 2)
    return {
      x: stage.w / 2,
      y: start + spec.order * step + h / 2,
      w,
      h,
      rotate: 0,
      scale: 1,
      opacity: 1,
      z: 10 + spec.order,
    }
  }
  const base = orbitBaseRadius(stage)
  const radii = [0.61, 0.89, 1.17]
  const radius = radii[spec.ring] * base
  const theta = (spec.angle * Math.PI) / 180
  const x = stage.w / 2 + radius * Math.cos(theta)
  const y = stage.h / 2 + radius * 0.6 * Math.sin(theta)
  const halfW = REST_W / 2 + 10
  const topH = REST_H / 2 + 10
  const bottomH = REST_H / 2 + 54
  return {
    x: Math.min(stage.w - halfW, Math.max(halfW, x)),
    y: Math.min(stage.h - bottomH, Math.max(topH, y)),
    w: REST_W,
    h: REST_H,
    rotate: cardTilt(spec),
    scale: spec.ring === 0 ? 1 : spec.ring === 1 ? 0.96 : 0.92,
    opacity: 1,
    z: spec.ring === 0 ? 16 : spec.ring === 1 ? 13 : 11 + spec.order,
  }
}

/** 展开工作区矩形：居中，四周至少留出卡片列的空间。 */
export function panelBox(stage: StageBox, wide: boolean): PanelBox {
  const horizontalRoom = stage.w < 900 ? 24 : wide ? 150 : 300
  const verticalRoom = stage.w < 900 ? 96 : 170
  const w = Math.min(wide ? 1080 : 900, stage.w - horizontalRoom)
  const h = Math.min(wide ? 640 : 590, stage.h - verticalRoom)
  return {
    x: (stage.w - w) / 2,
    y: (stage.h - h) / 2 + (wide ? -6 : 0),
    w,
    h,
  }
}

function distribute(count: number, stage: StageBox, cardH: number): number[] {
  if (count <= 0) return []
  const top = 86 + cardH / 2
  const bottom = stage.h - 58 - cardH / 2
  if (count === 1) return [(top + bottom) / 2]
  const span = Math.max(1, bottom - top)
  const step = Math.min(cardH + 16, span / (count - 1))
  const block = step * (count - 1)
  const start = (stage.h - block) / 2
  return Array.from({ length: count }, (_, index) => start + index * step)
}

/**
 * 展开 / 组合时的完整布局。
 * 主卡占据中心工作区；其余卡片被推成左右两列；
 * 与主卡有真实数据关系的卡片留在工作区下方，保持高亮并用连线相连。
 */
export function bloomPlacements(params: {
  stage: StageBox
  cards: CardSpec[]
  activeIds: string[]
  relatedIds: string[]
  panel: PanelBox
  wide: boolean
  combined: boolean
  mobile: boolean
}): Map<string, Placement> {
  const { stage, cards, activeIds, relatedIds, panel, wide, combined, mobile } = params
  const result = new Map<string, Placement>()
  const restMap = new Map<string, Placement>()

  const activeSet = new Set(activeIds)
  const relatedSet = new Set(relatedIds.filter((id) => !activeSet.has(id)))

  for (const spec of cards) {
    restMap.set(spec.id, restPlacement(stage, spec, false, cards.length))
  }

  if (mobile) {
    for (const spec of cards) {
      const base = restPlacement(stage, spec, true, cards.length)
      if (activeSet.has(spec.id)) {
        if (combined) {
          result.set(spec.id, { ...base, opacity: 0, scale: 0.9, z: 8 })
        } else {
          result.set(spec.id, {
            x: panel.x + panel.w / 2,
            y: panel.y + panel.h / 2,
            w: panel.w,
            h: panel.h,
            rotate: 0,
            scale: 1,
            opacity: 1,
            z: 50,
          })
        }
      } else {
        result.set(spec.id, { ...base, opacity: 0, scale: 0.94, z: 8 })
      }
    }
    return result
  }

  const compactScale = wide ? 0.64 : 0.68
  const compactW = REST_W * compactScale
  const compactH = REST_H * compactScale

  for (const spec of cards) {
    if (activeSet.has(spec.id)) {
      if (combined) {
        const index = activeIds.indexOf(spec.id)
        result.set(spec.id, {
          x: panel.x + panel.w * (index === 0 ? 0.22 : 0.78),
          y: panel.y + panel.h * 0.46,
          w: REST_W,
          h: REST_H,
          rotate: index === 0 ? -8 : 8,
          scale: 0.86,
          opacity: 0.35,
          z: 30,
        })
      } else if (activeIds.length > 1) {
        // 组合准备阶段：两片瓣向工作区中线靠拢，准备铰接。
        const index = activeIds.indexOf(spec.id)
        result.set(spec.id, {
          x: panel.x + panel.w * (index === 0 ? 0.24 : 0.76),
          y: panel.y + panel.h * 0.48,
          w: REST_W,
          h: REST_H,
          rotate: index === 0 ? -7 : 7,
          scale: 0.9,
          opacity: 0.9,
          z: 40,
        })
      } else {
        result.set(spec.id, {
          x: panel.x + panel.w / 2,
          y: panel.y + panel.h / 2,
          w: panel.w,
          h: panel.h,
          rotate: 0,
          scale: 1,
          opacity: 1,
          z: 42,
        })
      }
    }
  }

  if (combined || activeIds.length > 1) {
    // 组合态：工作区几乎占满舞台，其余卡片退到幕后保留轮廓，不做无意义堆叠。
    for (const spec of cards) {
      if (activeSet.has(spec.id)) continue
      const rest = restMap.get(spec.id)
      if (rest) result.set(spec.id, { ...rest, scale: 0.9, opacity: 0, z: 6 })
    }
    return result
  }

  const sideCards = cards.filter((spec) => !activeSet.has(spec.id) && !relatedSet.has(spec.id))
  const left = sideCards.filter((_, index) => index % 2 === 0)
  const right = sideCards.filter((_, index) => index % 2 === 1)
  const ysLeft = distribute(left.length, stage, compactH)
  const ysRight = distribute(right.length, stage, compactH)

  left.forEach((spec, index) => {
    result.set(spec.id, {
      x: 20 + compactW / 2,
      y: ysLeft[index],
      w: compactW,
      h: compactH,
      rotate: -6 + ((spec.seed % 5) * 1.6),
      scale: 1,
      opacity: 0.4,
      z: 16 + index,
    })
  })
  right.forEach((spec, index) => {
    result.set(spec.id, {
      x: stage.w - 20 - compactW / 2,
      y: ysRight[index],
      w: compactW,
      h: compactH,
      rotate: 5 - ((spec.seed % 5) * 1.5),
      scale: 1,
      opacity: 0.4,
      z: 16 + index,
    })
  })

  const related = cards.filter((spec) => relatedSet.has(spec.id))
  const bottomRoom = stage.h - (panel.y + panel.h)
  const placeBelow = bottomRoom >= compactH + 34
  const rowY = placeBelow
    ? Math.min(stage.h - 22 - compactH / 2, panel.y + panel.h + 16 + compactH / 2)
    : Math.max(22 + compactH / 2, panel.y - 16 - compactH / 2)
  related.forEach((spec, index) => {
    result.set(spec.id, {
      x: panel.x + (panel.w * (index + 1)) / (related.length + 1),
      y: rowY,
      w: compactW,
      h: compactH,
      rotate: (index - (related.length - 1) / 2) * 3,
      scale: 1,
      opacity: 0.92,
      z: 32 + index,
    })
  })

  return result
}

/** 从矩形面板中心朝目标点方向求边界的交点，用于绘制真实关系连线。 */
export function panelEdgePoint(panel: PanelBox, toward: Pt): Pt {
  const cx = panel.x + panel.w / 2
  const cy = panel.y + panel.h / 2
  const dx = toward.x - cx
  const dy = toward.y - cy
  if (dx === 0 && dy === 0) return { x: cx, y: cy }
  const tx = dx === 0 ? Number.POSITIVE_INFINITY : (panel.w / 2) / Math.abs(dx)
  const ty = dy === 0 ? Number.POSITIVE_INFINITY : (panel.h / 2) / Math.abs(dy)
  const t = Math.min(tx, ty)
  return { x: cx + dx * t, y: cy + dy * t }
}

/** 二次贝塞尔控制点：让连线像被拉开的纤维，而不是直线。 */
export function linkControlPoint(from: Pt, to: Pt, bend = 44): Pt {
  const mx = (from.x + to.x) / 2
  const my = (from.y + to.y) / 2
  const dx = to.x - from.x
  const dy = to.y - from.y
  const length = Math.hypot(dx, dy) || 1
  return {
    x: mx - (dy / length) * bend,
    y: my + (dx / length) * bend,
  }
}

/** 移动端舞台高度：由卡片数量决定，可自然滚动。 */
export function mobileStageHeight(count: number): number {
  return MOBILE_TOP + count * (MOBILE_CARD_H + 10) + 72
}
