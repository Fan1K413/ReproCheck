/** 功能 B：项目变化监控与影响分析（用户确认后才创建重审任务）。 */
import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Loader2, Radar, RefreshCw, ShieldCheck } from 'lucide-react'
import { useParams } from 'react-router-dom'
import { Modal } from '../components/Modal'
import { ErrorState } from '../components/ErrorState'
import { LoadingState } from '../components/LoadingState'
import { PageHeader } from '../components/PageHeader'
import { StatusBadge } from '../components/StatusBadge'
import { ApiError } from '../services/api'
import { researchApi } from '../services/researchApi'
import { toast } from '../stores/toastStore'

const CATEGORY_LABEL: Record<string, string> = {
  code: '代码', config: '配置', data: '数据', docs: '文档', other: '其它',
}

export default function ChangeMonitorPage() {
  const { projectId = '' } = useParams()
  const qc = useQueryClient()
  const [confirmOpen, setConfirmOpen] = useState(false)
  const [confirmed, setConfirmed] = useState(false)
  const analysisQ = useQuery({
    queryKey: ['change-monitor', projectId],
    queryFn: () => researchApi.changeMonitor(projectId), enabled: !!projectId,
  })
  const create = useMutation({
    mutationFn: () => researchApi.createReviewPlan(projectId, analysisQ.data?.new_snapshot_id ?? ''),
    onSuccess: () => { setConfirmOpen(false); setConfirmed(false); toast.success('已创建重审草稿，请到复现规划页人工确认'); void qc.invalidateQueries() },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : '创建失败'),
  })
  const data = analysisQ.data

  return (
    <div className="space-y-5">
      <PageHeader title="项目变化监控与影响分析"
        description="根据仓库真实 commit 与变更文件评估对事实、实验和审计结论的影响。普通 README 修改不会触发全量重跑。"
        actions={<button type="button" className="btn-ghost" onClick={() => void analysisQ.refetch()}>
          <RefreshCw size={15} className={analysisQ.isFetching ? 'animate-spin' : ''} /> 重新分析
        </button>} />

      {analysisQ.isPending ? <div className="panel"><LoadingState message="分析仓库变化…" /></div>
        : analysisQ.isError || !data ? (
          <div className="panel"><ErrorState message="无法获取变化分析" onRetry={() => void analysisQ.refetch()} /></div>
        ) : (
          <>
            <section className="panel overflow-hidden">
              <div className="panel-header">
                <div className="flex items-center gap-2"><Radar size={17} className="text-accent-dark" /><h3 className="text-sm font-semibold">快照对比</h3></div>
                <StatusBadge tone={data.status === 'analyzed' ? 'success' : 'neutral'}>{data.status}</StatusBadge>
              </div>
              <div className="px-5 py-4 text-sm">
                {data.status !== 'analyzed' ? <p className="text-ink-muted">{data.reason ?? '暂无足够数据。'}</p> : (
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="rounded border border-line bg-canvas p-3">
                      <div className="text-xs text-ink-muted">旧 commit</div>
                      <div className="mono mt-1 truncate text-xs">{data.old_commit || '—'}</div>
                    </div>
                    <div className="rounded border border-line bg-canvas p-3">
                      <div className="text-xs text-ink-muted">新 commit</div>
                      <div className="mono mt-1 truncate text-xs">{data.new_commit || '—'}</div>
                    </div>
                  </div>
                )}
              </div>
            </section>

            {data.status === 'analyzed' && (
              <>
                <section className="panel overflow-hidden">
                  <div className="panel-header"><h3 className="text-sm font-semibold">变更文件</h3></div>
                  <div className="px-5 py-4">
                    {data.changed_files.length === 0 ? <p className="text-sm text-ink-muted">快照未包含文件清单，影响范围无法确定。</p> : (
                      <div className="overflow-x-auto">
                        <table className="data-table data-table-dense">
                          <thead><tr><th>路径</th><th>状态</th><th>类别</th></tr></thead>
                          <tbody>
                            {data.changed_files.map((f) => (
                              <tr key={f.path}>
                                <td className="mono text-xs">{f.path}</td>
                                <td className="text-xs">{f.status || '—'}</td>
                                <td><StatusBadge tone={['code', 'config', 'data'].includes(f.category) ? 'warning' : 'neutral'}>
                                  {CATEGORY_LABEL[f.category] ?? f.category}
                                </StatusBadge></td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                </section>

                <div className="grid gap-4 lg:grid-cols-3">
                  {[
                    { title: '相关科研事实', items: data.affected_facts.map((f) => `${f.field} · ${f.matched_file}`) },
                    { title: '可能受影响的运行', items: data.affected_runs.map((r) => `${r.id} · ${r.impact}`) },
                    { title: '审计结论', items: data.affected_conclusions.map((c) => `${c.metric}: ${c.verdict} · ${c.impact}`) },
                  ].map((group) => (
                    <section key={group.title} className="panel overflow-hidden">
                      <div className="panel-header"><h3 className="text-sm font-semibold">{group.title}</h3></div>
                      <div className="space-y-1 px-5 py-4 text-xs">
                        {group.items.length === 0 && <p className="text-ink-muted">无直接证据。</p>}
                        {group.items.map((item, i) => <p key={i} className="mono break-all">{item}</p>)}
                      </div>
                    </section>
                  ))}
                </div>

                <section className="panel overflow-hidden">
                  <div className="panel-header"><h3 className="text-sm font-semibold">建议</h3></div>
                  <div className="space-y-2 px-5 py-4">
                    {data.suggestions.map((s, i) => (
                      <div key={i} className="flex items-start justify-between gap-3 rounded border border-line bg-canvas px-3 py-2 text-xs">
                        <div>
                          <div className="font-semibold">{s.title}
                            <span className="ml-2"><StatusBadge tone={s.severity === 'high' ? 'danger' : 'neutral'}>{s.severity}</StatusBadge></span>
                          </div>
                          <p className="mt-1 text-ink-muted">{s.reason}</p>
                        </div>
                        {s.requires_confirmation && data.new_snapshot_id && (
                          <button type="button" className="btn-ghost" onClick={() => setConfirmOpen(true)}>
                            创建重审草稿
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </section>

                <div className="flex items-start gap-2 rounded border border-line bg-canvas px-3 py-2 text-xs text-ink-muted">
                  <ShieldCheck size={14} className="mt-0.5 shrink-0 text-accent-dark" />
                  {data.notice ?? '影响分析基于确定性规则，相关不等于因果。'}
                </div>
              </>
            )}
          </>
        )}

      <Modal open={confirmOpen} title="确认创建重审任务"
        description="创建后仅生成复现规划草稿，不执行实验、不覆盖任何审计结论。"
        onClose={() => { setConfirmOpen(false); setConfirmed(false) }}
        footer={<>
          <button type="button" className="btn-ghost" onClick={() => setConfirmOpen(false)}>取消</button>
          <button type="button" className="btn-primary" disabled={!confirmed || create.isPending}
            onClick={() => create.mutate()}>
            {create.isPending ? <Loader2 size={15} className="animate-spin" /> : null} 确认创建
          </button>
        </>}>
        <label className="flex items-start gap-2 text-sm">
          <input type="checkbox" className="mt-1" checked={confirmed}
            onChange={(e) => setConfirmed(e.target.checked)} />
          <span>我已确认需要根据本次仓库变更创建重审草稿，并理解该操作不会自动执行实验。</span>
        </label>
      </Modal>
    </div>
  )
}
