import { useState } from 'react'
import { useParams } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  ChevronDown,
  Database,
  FileSearch,
  Loader2,
  Play,
  ShieldCheck,
  ShieldAlert,
} from 'lucide-react'
import { EmptyState } from '../components/EmptyState'
import { ErrorState } from '../components/ErrorState'
import { LoadingState } from '../components/LoadingState'
import { PageHeader } from '../components/PageHeader'
import { ApiError } from '../services/api'
import { dataAuditApi } from '../services/dataAuditApi'
import { toast } from '../stores/toastStore'
import type {
  DataAuditEvidence,
  DataAuditFinding,
  DataAuditReport,
  DataAuditSeverity,
} from '../types/dataAudit'

/* ------------------------------------------------------------------ 常量 */

const SEVERITY_META: Record<DataAuditSeverity, { label: string; color: string }> = {
  critical: { label: '严重', color: '#f87171' },
  high: { label: '高', color: '#fb923c' },
  medium: { label: '中', color: '#fbbf24' },
  low: { label: '低', color: '#60a5fa' },
  info: { label: '提示', color: '#34d399' },
  unknown: { label: '证据不足', color: '#94a3b8' },
}

const SEVERITY_ORDER: DataAuditSeverity[] = [
  'critical', 'high', 'medium', 'low', 'info', 'unknown',
]

const CATEGORY_LABEL: Record<string, string> = {
  integrity: '数据集完整性',
  leakage: '数据泄漏',
  distribution: '分布与统计',
  preprocessing: '数据预处理',
}

const PRIMARY_BTN =
  'inline-flex items-center gap-2 rounded-lg border border-emerald-400/60 bg-emerald-500/15 px-4 py-2 text-sm font-semibold text-emerald-200 transition hover:bg-emerald-500/25 disabled:cursor-not-allowed disabled:opacity-50'
const STATE_OVERRIDE = '[&_p]:!text-slate-300'

function formatTime(iso: string): string {
  const date = new Date(iso)
  return Number.isNaN(date.getTime()) ? iso : date.toLocaleString('zh-CN', { hour12: false })
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : '请求失败，请稍后重试。'
}

function errorCode(error: unknown): string | undefined {
  return error instanceof ApiError ? error.code : undefined
}

/* ------------------------------------------------------------------ 证据与发现 */

function EvidenceRow({ evidence }: { evidence: DataAuditEvidence }) {
  const items: Array<[string, string]> = [['数据文件', evidence.file_path]]
  if (evidence.sample_id) items.push(['样本标识', evidence.sample_id])
  if (evidence.field) items.push(['数据字段', evidence.field])
  if (evidence.code_location) items.push(['代码位置', evidence.code_location])
  if (evidence.paper_description) items.push(['论文描述', evidence.paper_description])
  if (evidence.dataset_version) items.push(['数据集版本', evidence.dataset_version])
  if (evidence.detail) items.push(['明细', evidence.detail])
  if (evidence.log_ref) items.push(['审计日志', evidence.log_ref])
  return (
    <div className="rounded-lg border border-slate-700 bg-navy-950/60 p-3">
      <dl className="grid gap-x-4 gap-y-1.5 sm:grid-cols-2">
        {items.map(([label, value]) => (
          <div key={label} className="min-w-0">
            <dt className="text-[11px] text-slate-400">{label}</dt>
            <dd className="mono break-all text-[11px] leading-4 text-slate-200">{value}</dd>
          </div>
        ))}
      </dl>
    </div>
  )
}

function FindingCard({ finding }: { finding: DataAuditFinding }) {
  const meta = SEVERITY_META[finding.severity] ?? SEVERITY_META.unknown
  return (
    <article className="rounded-lg border border-slate-700 bg-navy-900 p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex min-w-0 flex-wrap items-center gap-2">
          <span
            className="rounded-full border px-2.5 py-0.5 text-[11px] font-semibold"
            style={{ color: meta.color, borderColor: meta.color, backgroundColor: `${meta.color}1f` }}
          >
            {meta.label}
          </span>
          <span className="mono rounded bg-slate-700/60 px-2 py-0.5 text-[11px] text-slate-200">
            {finding.rule_id}
          </span>
          <span className="text-sm font-semibold text-slate-100">{finding.rule_name}</span>
        </div>
        <span className="text-[11px] text-slate-400">
          置信度：{finding.confidence}
          {finding.affects ? ` · 影响：${finding.affects}` : ''}
        </span>
      </div>
      <p className="mt-3 text-sm leading-6 text-slate-200">{finding.message}</p>
      {finding.justification && (
        <p className="mt-2 text-xs leading-5 text-slate-300">
          <span className="text-slate-400">判定依据：</span>
          {finding.justification}
        </p>
      )}
      <details className="group mt-3 rounded-lg border border-slate-700 bg-navy-800/60">
        <summary className="flex cursor-pointer list-none items-center gap-1.5 px-3 py-2 text-xs font-semibold text-emerald-300">
          <ChevronDown size={14} className="transition-transform group-open:rotate-180" />
          证据明细（{finding.evidence.length} 条）
        </summary>
        <div className="space-y-3 border-t border-slate-700 p-3">
          {finding.evidence.length === 0 ? (
            <p className="text-xs text-amber-300">该发现缺少可定位证据，不应作为结论依据。</p>
          ) : (
            finding.evidence.map((evidence, index) => (
              <EvidenceRow key={`${finding.rule_id}-e${index}`} evidence={evidence} />
            ))
          )}
        </div>
      </details>
      {finding.suggestion && (
        <p className="mt-3 text-xs leading-5 text-amber-200">
          <span className="text-amber-300/80">复核建议：</span>
          {finding.suggestion}
        </p>
      )}
    </article>
  )
}

/* ------------------------------------------------------------------ 报告视图 */

function ReportView({ report }: { report: DataAuditReport }) {
  const categories = new Map<string, DataAuditFinding[]>()
  for (const finding of report.findings) {
    const rule = finding.rule_id.split('-')[0]
    const key =
      rule === 'INT' ? 'integrity' : rule === 'LEAK' ? 'leakage'
      : rule === 'DIST' ? 'distribution' : 'preprocessing'
    categories.set(key, [...(categories.get(key) ?? []), finding])
  }

  return (
    <div className="flex flex-col gap-5">
      <section className="rounded-xl border border-slate-700 bg-navy-800 p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs text-slate-400">
              审计编号 <span className="mono text-slate-200">{report.audit_id}</span>
            </p>
            <p className="mt-1 text-xs text-slate-400">
              生成时间：{formatTime(report.created_at)} · 版本：{report.version} ·
              耗时 {report.duration_ms} ms
            </p>
            <p className="mt-1 flex flex-wrap items-center gap-3 text-[11px] text-slate-400">
              <span className="inline-flex items-center gap-1">
                <ShieldCheck size={13} className="text-emerald-400" />
                只读执行：{report.scope.read_only ? '是' : '否'}
              </span>
              <span className="inline-flex items-center gap-1">
                <ShieldCheck size={13} className="text-emerald-400" />
                外部调用：{report.scope.external_calls ? '有' : '无'}
              </span>
              <span>采样上限 {report.scope.limits?.sample_rows ?? '—'} 行/文件</span>
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-full border border-red-400/60 bg-red-400/10 px-3 py-1 text-xs font-semibold text-red-300">
              阻断项 {report.blocking_count}
            </span>
            <span className="rounded-full border border-slate-600 bg-slate-700/40 px-3 py-1 text-xs font-semibold text-slate-300">
              发现 {report.findings.length} 条
            </span>
          </div>
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {SEVERITY_ORDER.map((severity) => (
            <div key={severity} className="rounded-lg border border-slate-700 bg-navy-900 p-3">
              <p className="text-[11px] text-slate-400">{SEVERITY_META[severity].label}</p>
              <p
                className="mono mt-1 text-xl font-semibold"
                style={{ color: SEVERITY_META[severity].color }}
              >
                {report.counts[severity] ?? 0}
              </p>
            </div>
          ))}
        </div>
        {report.stats && (
          <p className="mt-3 text-[11px] text-slate-400">
            扫描文件 {String(report.stats.files_scanned ?? 0)} 个 ·
            代码文件 {String(report.stats.code_files_scanned ?? 0)} 个 ·
            总行数 {String(report.stats.total_rows ?? 0)} ·
            数据集版本 {report.stats.dataset_version
              ? String(report.stats.dataset_version)
              : '未识别'}
          </p>
        )}
      </section>

      {report.findings.length === 0 ? (
        <div className={STATE_OVERRIDE}>
          <EmptyState
            title="未发现问题"
            description="本次扫描未触发任何规则；「证据不足」类规则结果见规则执行概览。"
            compact
          />
        </div>
      ) : (
        Array.from(categories.entries()).map(([category, findings]) => (
          <section key={category} className="rounded-xl border border-slate-700 bg-navy-800 p-5">
            <h3 className="text-sm font-semibold text-slate-100">
              {CATEGORY_LABEL[category] ?? category}
              <span className="ml-2 text-xs font-normal text-slate-400">
                {findings.length} 条
              </span>
            </h3>
            <div className="mt-4 flex flex-col gap-3">
              {findings.map((finding, index) => (
                <FindingCard key={`${finding.rule_id}-${index}`} finding={finding} />
              ))}
            </div>
          </section>
        ))
      )}

      <RuleResultsTable ruleResults={report.rule_results} />
    </div>
  )
}

function RuleResultsTable({ ruleResults }: { ruleResults: Record<string, string> }) {
  const entries = Object.entries(ruleResults)
  const meta: Record<string, { label: string; color: string }> = {
    fail: { label: '触发', color: '#f87171' },
    pass: { label: '通过', color: '#34d399' },
    skipped: { label: '未评估', color: '#94a3b8' },
  }
  return (
    <section className="rounded-xl border border-slate-700 bg-navy-800 p-5">
      <div className="flex items-center gap-2">
        <Database size={16} className="text-emerald-300" />
        <h3 className="text-sm font-semibold text-slate-100">规则执行概览</h3>
      </div>
      <p className="mt-1 text-xs text-slate-400">
        「未评估」表示当前数据/代码条件下该规则无法得出结论，不代表通过。
      </p>
      <div className="mt-4 flex flex-wrap gap-2">
        {entries.map(([ruleId, result]) => {
          const m = meta[result] ?? meta.skipped
          return (
            <span
              key={ruleId}
              title={`${ruleId}: ${m.label}`}
              className="mono rounded border px-2 py-0.5 text-[11px]"
              style={{ color: m.color, borderColor: m.color, backgroundColor: `${m.color}14` }}
            >
              {ruleId} {m.label}
            </span>
          )
        })}
      </div>
    </section>
  )
}

/* ------------------------------------------------------------------ 页面主体 */

export default function DataAuditPage() {
  const { projectId = '' } = useParams()
  const queryClient = useQueryClient()
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [includeCodeScan, setIncludeCodeScan] = useState(true)

  const listQuery = useQuery({
    queryKey: ['data-audit', 'list', projectId],
    queryFn: () => dataAuditApi.list(projectId),
    enabled: Boolean(projectId),
    retry: 1,
  })

  const runMutation = useMutation({
    mutationFn: () => dataAuditApi.run(projectId, { include_code_scan: includeCodeScan }),
    onSuccess: (report) => {
      toast.success(`审计完成：${report.findings.length} 条发现，阻断 ${report.blocking_count} 条`)
      setSelectedId(report.audit_id)
      void queryClient.invalidateQueries({ queryKey: ['data-audit', 'list', projectId] })
    },
    onError: (error) => toast.error(`数据审计失败：${errorMessage(error)}`),
  })

  const detailQuery = useQuery({
    queryKey: ['data-audit', 'detail', projectId, selectedId],
    queryFn: () => dataAuditApi.get(projectId, selectedId as string),
    enabled: Boolean(projectId && selectedId),
    retry: 0,
  })

  const rulesQuery = useQuery({
    queryKey: ['data-audit', 'rules'],
    queryFn: dataAuditApi.rules,
    retry: 1,
  })

  const report = detailQuery.data ?? runMutation.data
  const latestId = listQuery.data?.items?.[0]?.audit_id ?? null

  return (
    <div className="min-h-screen bg-navy-950 px-5 py-6 text-slate-100">
      <div className="mx-auto flex max-w-7xl flex-col gap-5">
        <div className={STATE_OVERRIDE}>
          <PageHeader
            title="数据质量审计"
            description="检查数据集完整性、数据泄漏、分布统计与预处理一致性——只读执行，全部发现附带证据"
          />
        </div>

        <section className="rounded-xl border border-slate-700 bg-navy-800 p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-100">
                <FileSearch size={16} className="text-emerald-300" />
                执行审计
              </h3>
              <p className="mt-1 text-xs text-slate-400">
                对项目已上传的数据材料做本地只读扫描：不上传、不外发、不修改原文件。
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <label className="flex cursor-pointer items-center gap-2 text-xs text-slate-300">
                <input
                  type="checkbox"
                  checked={includeCodeScan}
                  onChange={(event) => setIncludeCodeScan(event.target.checked)}
                  className="h-4 w-4 rounded border-slate-600 bg-navy-950 accent-emerald-500"
                />
                同时扫描代码（泄漏/预处理规则）
              </label>
              <button
                type="button"
                className={PRIMARY_BTN}
                disabled={runMutation.isPending || !projectId}
                onClick={() => runMutation.mutate()}
              >
                {runMutation.isPending ? (
                  <Loader2 size={15} className="animate-spin" />
                ) : (
                  <Play size={15} />
                )}
                {runMutation.isPending ? '审计中…' : '运行数据审计'}
              </button>
            </div>
          </div>
        </section>

        {runMutation.isPending && (
          <div className={STATE_OVERRIDE}>
            <LoadingState
              message="正在执行数据审计…"
              hint="分块读取、哈希与规则计算均为本地确定性过程。"
              compact
            />
          </div>
        )}
        {runMutation.isError && (
          <div className={STATE_OVERRIDE}>
            <ErrorState
              message={errorMessage(runMutation.error)}
              code={errorCode(runMutation.error)}
              onRetry={() => runMutation.mutate()}
              compact
            />
          </div>
        )}
        {detailQuery.isError && (
          <div className={STATE_OVERRIDE}>
            <ErrorState
              message={errorMessage(detailQuery.error)}
              code={errorCode(detailQuery.error)}
              onRetry={() => detailQuery.refetch()}
              compact
            />
          </div>
        )}
        {report && !runMutation.isPending && (
          <ReportView report={report} />
        )}
        {!report && !runMutation.isPending && !runMutation.isError && (
          <div className={STATE_OVERRIDE}>
            <EmptyState
              title="暂无审计结果"
              description={
                latestId
                  ? '点击「运行数据审计」执行新的扫描，或从历史记录中选择一次审计查看报告。'
                  : '项目还没有数据材料。先在「材料管理」上传 CSV/JSONL 等数据文件，再运行审计。'
              }
              compact
            />
          </div>
        )}

        {/* 历史记录 */}
        <section className="rounded-xl border border-slate-700 bg-navy-800 p-5">
          <h3 className="text-sm font-semibold text-slate-100">历史审计</h3>
          {listQuery.isPending ? (
            <div className={STATE_OVERRIDE}>
              <LoadingState message="加载历史记录…" compact />
            </div>
          ) : (listQuery.data?.items.length ?? 0) === 0 ? (
            <p className="mt-3 text-xs text-slate-400">尚无历史审计记录。</p>
          ) : (
            <ul className="mt-3 flex flex-col divide-y divide-slate-700/70">
              {listQuery.data?.items.map((item) => (
                <li key={item.audit_id}>
                  <button
                    type="button"
                    onClick={() => setSelectedId(item.audit_id)}
                    className={`flex w-full flex-wrap items-center justify-between gap-2 px-1 py-2.5 text-left transition hover:bg-navy-700/40 ${
                      selectedId === item.audit_id ? 'bg-navy-700/50' : ''
                    }`}
                  >
                    <span className="mono text-[11px] text-slate-300">
                      {item.audit_id.slice(0, 12)}…
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {item.created_at ? formatTime(item.created_at) : '—'}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      发现 {item.finding_count} · 阻断 {item.blocking_count} ·{' '}
                      {item.duration_ms} ms
                    </span>
                    {item.blocking_count > 0 ? (
                      <ShieldAlert size={14} className="text-red-400" />
                    ) : (
                      <ShieldCheck size={14} className="text-emerald-400" />
                    )}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* 规则目录 */}
        <section className="rounded-xl border border-slate-700 bg-navy-800 p-5">
          <h3 className="text-sm font-semibold text-slate-100">
            审计规则目录
            <span className="ml-2 text-xs font-normal text-slate-400">
              {rulesQuery.data?.total ?? '—'} 条
            </span>
          </h3>
          {rulesQuery.isPending ? (
            <div className={STATE_OVERRIDE}>
              <LoadingState message="加载规则目录…" compact />
            </div>
          ) : rulesQuery.isError ? (
            <p className="mt-3 text-xs text-amber-300">规则目录加载失败。</p>
          ) : (
            <div className="mt-3 overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-700 text-slate-400">
                    <th className="py-2 pr-4 font-semibold">规则</th>
                    <th className="py-2 pr-4 font-semibold">类别</th>
                    <th className="py-2 pr-4 font-semibold">默认严重度</th>
                    <th className="py-2 font-semibold">说明</th>
                  </tr>
                </thead>
                <tbody>
                  {rulesQuery.data?.items.map((rule) => {
                    const sev = SEVERITY_META[rule.default_severity] ?? SEVERITY_META.unknown
                    return (
                      <tr key={rule.rule_id} className="border-b border-slate-800/80">
                        <td className="mono py-2 pr-4 text-slate-200">{rule.rule_id}</td>
                        <td className="py-2 pr-4 text-slate-300">
                          {CATEGORY_LABEL[rule.category] ?? rule.category}
                        </td>
                        <td className="py-2 pr-4">
                          <span
                            className="rounded-full border px-2 py-0.5 text-[10px] font-semibold"
                            style={{
                              color: sev.color,
                              borderColor: sev.color,
                              backgroundColor: `${sev.color}1f`,
                            }}
                          >
                            {sev.label}
                          </span>
                        </td>
                        <td className="py-2 text-slate-400">{rule.description}</td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </div>
  )
}
