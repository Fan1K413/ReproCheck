/** 功能 A：科研实验差异分析中心（确定性分析，相关性≠因果性）。 */
import { useState } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import { GitCompare, Loader2, Play, ShieldAlert } from 'lucide-react'
import { useParams } from 'react-router-dom'
import { ErrorState } from '../components/ErrorState'
import { LoadingState } from '../components/LoadingState'
import { PageHeader } from '../components/PageHeader'
import { StatusBadge } from '../components/StatusBadge'
import { formatDateTime } from '../features/format'
import { ApiError } from '../services/api'
import { researchApi } from '../services/researchApi'
import { toast } from '../stores/toastStore'

export default function ExperimentDiffPage() {
  const { projectId = '' } = useParams()
  const [selected, setSelected] = useState<string[]>([])
  const runsQ = useQuery({ queryKey: ['exp-runs', projectId], queryFn: () => researchApi.runs(projectId), enabled: !!projectId })
  const diff = useMutation({
    mutationFn: () => researchApi.diff(projectId, selected),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : '差异分析失败'),
  })

  const toggle = (id: string) => setSelected((prev) =>
    prev.includes(id) ? prev.filter((x) => x !== id) : prev.length < 5 ? [...prev, id] : prev)

  return (
    <div className="space-y-5">
      <PageHeader title="实验差异分析中心"
        description="比较两个或多个实验版本，找出条件与指标变化；只给出相关性线索，不认定因果。" />

      <section className="panel overflow-hidden">
        <div className="panel-header">
          <div className="flex items-center gap-2"><GitCompare size={17} className="text-accent-dark" /><h3 className="text-sm font-semibold">选择实验版本</h3></div>
          <span className="text-xs text-ink-muted">已选 {selected.length} / 5</span>
        </div>
        <div className="px-5 py-4">
          {runsQ.isPending ? <LoadingState message="读取运行列表…" /> : runsQ.isError ? (
            <ErrorState message="无法读取运行列表" onRetry={() => void runsQ.refetch()} />
          ) : (runsQ.data ?? []).length === 0 ? (
            <p className="py-4 text-center text-sm text-ink-muted">该项目还没有运行记录，无法比较。</p>
          ) : (
            <div className="space-y-2">
              {(runsQ.data ?? []).map((r) => (
                <label key={r.id} className="flex cursor-pointer items-center gap-3 rounded border border-line px-3 py-2 text-sm hover:bg-canvas">
                  <input type="checkbox" checked={selected.includes(r.id)} onChange={() => toggle(r.id)} />
                  <span className="mono text-xs">{r.id}</span>
                  <StatusBadge tone={r.status === 'completed' ? 'success' : 'neutral'}>{r.status}</StatusBadge>
                  <span className="text-xs text-ink-muted">{formatDateTime(r.started_at)} · {r.duration_ms}ms</span>
                </label>
              ))}
              <button type="button" className="btn-primary mt-2" disabled={selected.length < 2 || diff.isPending}
                onClick={() => diff.mutate()}>
                {diff.isPending ? <Loader2 size={15} className="animate-spin" /> : <Play size={15} />} 生成差异报告
              </button>
            </div>
          )}
        </div>
      </section>

      {diff.data && (
        <div className="space-y-4">
          <section className="panel overflow-hidden">
            <div className="panel-header"><h3 className="text-sm font-semibold">条件变化</h3></div>
            <div className="px-5 py-4">
              <div className="overflow-x-auto">
                <table className="data-table data-table-dense">
                  <thead><tr><th>维度</th><th>状态</th><th>数据完整性</th></tr></thead>
                  <tbody>
                    {diff.data.conditions.map((c) => (
                      <tr key={c.dimension}>
                        <td className="mono text-xs">{c.dimension}</td>
                        <td><StatusBadge tone={c.status === 'changed' ? 'warning' : 'neutral'}>{c.status}</StatusBadge></td>
                        <td className="text-xs">{c.unknown ? '未知（缺数据）' : '可比较'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          <section className="panel overflow-hidden">
            <div className="panel-header"><h3 className="text-sm font-semibold">指标变化</h3></div>
            <div className="px-5 py-4">
              <div className="overflow-x-auto">
                <table className="data-table data-table-dense">
                  <thead><tr><th>指标</th><th>各版本值</th><th>绝对差</th><th>相对差</th><th>结论</th></tr></thead>
                  <tbody>
                    {diff.data.metric_diffs.map((m) => (
                      <tr key={m.metric}>
                        <td className="font-medium">{m.metric}</td>
                        <td className="mono text-xs">{m.values.map((v) => v ?? '—').join(' → ')}</td>
                        <td className="mono text-xs">{m.absolute_diff ?? '—'}</td>
                        <td className="mono text-xs">{m.relative_diff ?? '—'}</td>
                        <td><StatusBadge tone={m.changed ? 'warning' : 'neutral'}>{m.changed ? '变化' : '未变'}</StatusBadge></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          <div className="grid gap-4 lg:grid-cols-2">
            <section className="panel overflow-hidden">
              <div className="panel-header"><h3 className="text-sm font-semibold">可能解释（仅相关性）</h3></div>
              <div className="space-y-2 px-5 py-4 text-xs">
                {diff.data.possible_explanations.length === 0 && <p className="text-ink-muted">未发现可归因的线索。</p>}
                {diff.data.possible_explanations.map((e, i) => (
                  <div key={i} className="rounded border border-line bg-canvas p-2">
                    <span className="mono font-semibold">{e.condition}</span> → {e.metrics.join(', ')}
                    <p className="mt-1 text-ink-muted">{e.text}</p>
                  </div>
                ))}
              </div>
            </section>
            <section className="panel overflow-hidden">
              <div className="panel-header"><h3 className="text-sm font-semibold">重跑建议与不确定项</h3></div>
              <div className="space-y-2 px-5 py-4 text-xs">
                <p><span className="font-semibold">建议：</span>{diff.data.rerun_recommendation.recommendation} — {diff.data.rerun_recommendation.reason}</p>
                <p><span className="font-semibold">无法确定：</span>{diff.data.undetermined.join('、') || '无'}</p>
                {diff.data.affected_audit_conclusions.map((c) => (
                  <p key={c.id} className="text-ink-muted">{c.metric}: {c.verdict} · {c.impact}</p>
                ))}
              </div>
            </section>
          </div>

          <div className="flex items-start gap-2 rounded border border-warning/40 bg-warning/5 px-3 py-2 text-xs text-ink-muted">
            <ShieldAlert size={14} className="mt-0.5 shrink-0 text-warning" />
            {diff.data.causality_notice}
          </div>
        </div>
      )}
    </div>
  )
}
