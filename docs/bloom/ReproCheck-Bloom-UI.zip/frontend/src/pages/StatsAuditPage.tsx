import { useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import {
  Activity,
  BarChart3,
  Calculator,
  ChevronDown,
  FlaskConical,
  Loader2,
  Play,
  RotateCcw,
  ShieldAlert,
  ShieldCheck,
} from 'lucide-react'
import { EmptyState } from '../components/EmptyState'
import { ErrorState } from '../components/ErrorState'
import { LoadingState } from '../components/LoadingState'
import { PageHeader } from '../components/PageHeader'
import { ApiError } from '../services/api'
import { statsApi } from '../services/statsApi'
import { toast } from '../stores/toastStore'
import type {
  StatsComputeResult,
  StatsEvidence,
  StatsReport,
  StatsVerdict,
} from '../types/stats'

/* ------------------------------------------------------------------ 常量 */

const VERDICT_META: Record<StatsVerdict, { label: string; color: string; hint: string }> = {
  calculation_error: {
    label: '计算错误',
    color: '#f87171',
    hint: '重算值与报告值不一致',
  },
  method_inapplicable: {
    label: '统计方法不适用',
    color: '#fb923c',
    hint: '方法前提或口径存疑',
  },
  insufficient_evidence: {
    label: '证据不足',
    color: '#94a3b8',
    hint: '输入数据不足以判断',
  },
  potential_bias: {
    label: '潜在偏差',
    color: '#fbbf24',
    hint: '报告或选取口径需核对',
  },
  needs_human_review: {
    label: '需要人工复核',
    color: '#60a5fa',
    hint: '无法自动定性',
  },
  verified: {
    label: '已得到数据验证',
    color: '#34d399',
    hint: '按公开公式复算一致',
  },
}

const VERDICT_ORDER: StatsVerdict[] = [
  'calculation_error',
  'method_inapplicable',
  'insufficient_evidence',
  'potential_bias',
  'needs_human_review',
  'verified',
]

const FALLBACK_OPERATIONS = [
  'mean',
  'std',
  'variance',
  'verify_mean_std',
  'check_consistency',
  'analyze_seed_impact',
  'confidence_interval',
  'effect_size',
  'hypothesis_test',
  'multiple_comparison',
  'power_analysis',
  'detect_outliers',
  'distribution_data',
  'compute_classification_metrics',
  'compute_roc_auc',
  'audit_metric_claims',
  'check_control_group',
  'guard_causal_language',
]

/** 官方合成示例：非真实论文数据，仅用于演示输入结构与复算链路。 */
const SAMPLE_DATA = {
  claims: {
    mean: 0.82,
    std: 0.04,
    accuracy: 0.9,
    f1: 0.88,
  },
  samples: {
    values: [0.78, 0.81, 0.83, 0.85, 0.79, 0.82, 0.86, 0.8, 0.84, 0.83],
    ddof: 1,
  },
  runs: [
    { name: 'run_1', values: [0.79, 0.81, 0.83, 0.8, 0.82] },
    { name: 'run_2', values: [0.82, 0.84, 0.85, 0.83, 0.84] },
    { name: 'run_3', values: [0.8, 0.79, 0.82, 0.81, 0.83] },
  ],
  seed_scores: {
    seed_42: [0.82, 0.84, 0.81, 0.83, 0.85],
    seed_7: [0.74, 0.76, 0.75, 0.73, 0.77],
    seed_2024: [0.83, 0.86, 0.84, 0.85, 0.82],
  },
  group_a: [0.82, 0.84, 0.85, 0.83, 0.86, 0.81, 0.84, 0.83],
  group_b: [0.75, 0.74, 0.77, 0.76, 0.73, 0.78, 0.75, 0.76],
  alpha: 0.05,
  test_kind: 'welch',
  pvalues: [0.01, 0.02, 0.03, 0.04, 0.2],
  multiple_method: 'holm',
  multiple_comparison_corrected: false,
  effect_size: 0.55,
  n: 40,
  bins: 8,
  dataset: {
    task_type: 'classification',
    y_true: [1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0],
    y_pred: [1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0],
    y_score: [0.9, 0.2, 0.8, 0.3, 0.4, 0.88, 0.15, 0.65, 0.75, 0.25, 0.92, 0.35],
    labels: [0, 1],
  },
  control_group: {
    baseline_declared: true,
    randomization_declared: true,
    blinding_declared: false,
  },
  claimed_components: ['特征模块', '编码模块', '校准模块'],
  ablations: ['去除特征模块', '去除编码模块'],
  baselines: ['同期基线模型'],
  reported_seeds: [42],
  total_seeds: 3,
  reported_splits: ['test'],
  best_only: true,
  n_repeats: 2,
  pvalue: 0.02,
}

const SAMPLE_JSON = JSON.stringify(SAMPLE_DATA, null, 2)
const DEFAULT_KWARGS = JSON.stringify({ values: [1, 2, 3, 4, 5] }, null, 2)

const PRIMARY_BTN =
  'inline-flex items-center gap-2 rounded-lg border border-emerald-400/60 bg-emerald-500/15 px-4 py-2 text-sm font-semibold text-emerald-200 transition hover:bg-emerald-500/25 disabled:cursor-not-allowed disabled:opacity-50'
const SECONDARY_BTN =
  'inline-flex items-center gap-2 rounded-lg border border-slate-600 bg-slate-700/40 px-3 py-2 text-xs font-semibold text-slate-200 transition hover:bg-slate-700/70'
const TEXTAREA_CLS =
  'mono w-full resize-y rounded-lg border border-slate-700 bg-navy-950 p-3 text-xs leading-5 text-slate-200 outline-none placeholder:text-slate-500 focus:border-emerald-400'
const STATE_OVERRIDE = '[&_p]:!text-slate-300'

type Mode = 'full' | 'compute'
type HistogramData = { counts: number[]; edges: number[]; source: string }
type CiRow = { label: string; low: number; high: number; center: number }
type SeedRow = { seed: string; mean: number; std: number | null }

/* ------------------------------------------------------------------ 工具 */

function asRecord(value: unknown): Record<string, unknown> | null {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return null
  return value as Record<string, unknown>
}

function asFiniteNumber(value: unknown): number | null {
  return typeof value === 'number' && Number.isFinite(value) ? value : null
}

function asNumberArray(value: unknown): number[] | null {
  if (!Array.isArray(value)) return null
  const out: number[] = []
  for (const item of value) {
    const num = asFiniteNumber(item)
    if (num === null) return null
    out.push(num)
  }
  return out
}

function formatJson(value: unknown): string {
  if (value === undefined) return '—'
  try {
    return JSON.stringify(value, null, 2) ?? '—'
  } catch {
    return '无法序列化'
  }
}

function formatNumber(value: number): string {
  if (!Number.isFinite(value)) return '—'
  if (Math.abs(value) >= 1000) return value.toFixed(0)
  return Number(value.toFixed(3)).toString()
}

function formatTime(iso: string): string {
  const date = new Date(iso)
  return Number.isNaN(date.getTime()) ? iso : date.toLocaleString('zh-CN', { hour12: false })
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : '请求失败，请稍后重试。'
}

function errorCode(error: unknown): string | undefined {
  return error instanceof ApiError ? error.code : undefined
}

function parseObject(text: string, label: string): Record<string, unknown> {
  let parsed: unknown
  try {
    parsed = JSON.parse(text) as unknown
  } catch {
    throw new Error(`${label}不是合法的 JSON。`)
  }
  const record = asRecord(parsed)
  if (!record) throw new Error(`${label}必须是 JSON 对象。`)
  return record
}

function resultParts(value: unknown): {
  top: Record<string, unknown>
  values: Record<string, unknown>
} {
  const top = asRecord(value) ?? {}
  return { top, values: asRecord(top.values) ?? {} }
}

/** 直方图数据：优先取 core.distribution_data，并兼容别名与顶层 counts/bin_edges。 */
function collectHistogram(report: StatsReport): HistogramData | null {
  const candidates = [
    'core.distribution_data',
    'distribution_data',
    'core.STAT-010',
    'STAT-010',
  ]
  for (const key of candidates) {
    if (!Object.prototype.hasOwnProperty.call(report.computations, key)) continue
    const { top, values } = resultParts(report.computations[key])
    const counts = asNumberArray(values.counts ?? top.counts)
    if (!counts || counts.length === 0) continue
    const rawEdges = asNumberArray(values.bin_edges ?? top.bin_edges)
    const edges =
      rawEdges && rawEdges.length >= counts.length + 1
        ? rawEdges
        : Array.from({ length: counts.length + 1 }, (_, index) => index)
    return { counts, edges, source: key }
  }
  return null
}

/** 森林图数据：发现证据的 ci_low/ci_high/mean 与 computations 中的置信区间结果。 */
function collectCiRows(report: StatsReport): CiRow[] {
  const rows: CiRow[] = []
  const pushRow = (label: string, low: number | null, high: number | null, center: number | null) => {
    if (low === null || high === null || !Number.isFinite(low) || !Number.isFinite(high)) return
    const point = center ?? (low + high) / 2
    rows.push({ label, low, high, center: Number.isFinite(point) ? point : (low + high) / 2 })
  }

  for (const finding of report.findings) {
    for (const evidence of finding.evidence) {
      const recomputed = asRecord(evidence.recomputed)
      if (!recomputed) continue
      pushRow(
        finding.rule_id,
        asFiniteNumber(recomputed.ci_low),
        asFiniteNumber(recomputed.ci_high),
        asFiniteNumber(recomputed.mean),
      )
    }
  }

  for (const [key, value] of Object.entries(report.computations)) {
    const normalized = key.replace(/^core\./, '')
    if (!normalized.includes('confidence') && !normalized.includes('STAT-004')) continue
    const { top, values } = resultParts(value)
    const source = asFiniteNumber(values.ci_low) !== null ? values : top
    pushRow(
      normalized,
      asFiniteNumber(source.ci_low),
      asFiniteNumber(source.ci_high),
      asFiniteNumber(source.mean),
    )
  }

  const seen = new Set<string>()
  return rows
    .filter((row) => {
      const key = `${row.label}|${row.low}|${row.high}`
      if (seen.has(key)) return false
      seen.add(key)
      return true
    })
    .slice(0, 8)
}

/** 种子影响数据：优先用 per_seed 汇总，其次从证据输入中的 seed_scores 逐组求均值。 */
function collectSeedRows(report: StatsReport): SeedRow[] {
  const candidates = [
    'core.analyze_seed_impact',
    'analyze_seed_impact',
    'core.STAT-003',
    'STAT-003',
  ]
  for (const key of candidates) {
    if (!Object.prototype.hasOwnProperty.call(report.computations, key)) continue
    const { top, values } = resultParts(report.computations[key])
    const perSeed = values.per_seed ?? top.per_seed
    if (!Array.isArray(perSeed)) continue
    const rows: SeedRow[] = []
    for (const item of perSeed) {
      const record = asRecord(item)
      if (!record) continue
      const mean = asFiniteNumber(record.mean)
      if (mean === null) continue
      const seed = typeof record.seed === 'string' ? record.seed : String(record.seed ?? `种子${rows.length + 1}`)
      rows.push({ seed, mean, std: asFiniteNumber(record.std) })
    }
    if (rows.length > 0) return rows
  }

  for (const finding of report.findings) {
    for (const evidence of finding.evidence) {
      const inputs = asRecord(evidence.inputs)
      const seeds = asRecord(inputs?.seed_scores)
      if (!seeds) continue
      const rows: SeedRow[] = []
      for (const [seed, raw] of Object.entries(seeds)) {
        const scores = asNumberArray(raw)
        if (!scores || scores.length === 0) continue
        rows.push({
          seed,
          mean: scores.reduce((sum, item) => sum + item, 0) / scores.length,
          std: null,
        })
      }
      if (rows.length > 0) return rows
    }
  }
  return []
}

/* ------------------------------------------------------------------ 通用展示组件 */

function VerdictBadge({
  verdict,
  label,
  count,
}: {
  verdict: StatsVerdict
  label?: string
  count?: number
}) {
  const meta = VERDICT_META[verdict] ?? VERDICT_META.verified
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-semibold"
      style={{ color: meta.color, borderColor: meta.color, backgroundColor: `${meta.color}1f` }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: meta.color }} />
      {label ?? meta.label}
      {count !== undefined ? ` · ${count}` : ''}
    </span>
  )
}

function ChartPanel({
  title,
  hint,
  legend,
  empty,
  children,
}: {
  title: string
  hint: string
  legend: Array<{ color: string; label: string; shape: 'bar' | 'line' | 'dot' }>
  empty: boolean
  children: ReactNode
}) {
  return (
    <section className="rounded-xl border border-slate-700 bg-navy-800 p-4">
      <div className="mb-3 flex flex-wrap items-start justify-between gap-2">
        <div className="min-w-0">
          <h4 className="flex items-center gap-1.5 text-sm font-semibold text-slate-100">
            <BarChart3 size={14} className="text-emerald-300" />
            {title}
          </h4>
          <p className="mt-0.5 text-[11px] text-slate-400">{hint}</p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          {legend.map((item) => (
            <span key={item.label} className="inline-flex items-center gap-1.5 text-[10px] text-slate-400">
              <span
                className={item.shape === 'dot' ? 'h-2 w-2 rounded-full' : 'h-0.5 w-4 rounded'}
                style={{ backgroundColor: item.color }}
              />
              {item.label}
            </span>
          ))}
        </div>
      </div>
      {empty ? (
        <div className="flex h-[210px] items-center justify-center rounded-lg border border-dashed border-slate-700 bg-navy-950/40 text-sm text-slate-400">
          暂无可可视化数据
        </div>
      ) : (
        children
      )}
    </section>
  )
}

/* ------------------------------------------------------------------ 手写 SVG 图表 */

function HistogramChart({ data }: { data: HistogramData }) {
  const width = 640
  const height = 240
  const left = 48
  const right = 16
  const top = 16
  const bottom = 40
  const plotW = width - left - right
  const plotH = height - top - bottom
  const { counts, edges } = data
  const maxCount = Math.max(...counts, 1)
  const first = edges[0] ?? 0
  const last = edges[edges.length - 1] ?? first + 1
  const span = last - first || 1
  const xAt = (edge: number) => left + ((edge - first) / span) * plotW
  const xTicks = [0, 0.25, 0.5, 0.75, 1].map((ratio) => first + ratio * span)
  const yTicks = [0, maxCount / 2, maxCount]

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="w-full" role="img" aria-label="样本分布直方图">
      {yTicks.map((tick, index) => {
        const y = top + plotH - (tick / maxCount) * plotH
        return (
          <g key={`y-${index}`}>
            <line x1={left} y1={y} x2={left + plotW} y2={y} stroke="#334155" strokeWidth="1" strokeDasharray="4 4" />
            <text x={left - 6} y={y + 3} fill="#94a3b8" fontSize="10" textAnchor="end">
              {formatNumber(tick)}
            </text>
          </g>
        )
      })}
      <line x1={left} y1={top + plotH} x2={left + plotW} y2={top + plotH} stroke="#94a3b8" strokeWidth="1" />
      <line x1={left} y1={top} x2={left} y2={top + plotH} stroke="#94a3b8" strokeWidth="1" />
      {counts.map((count, index) => {
        const x0 = xAt(edges[index] ?? first + (index * span) / counts.length)
        const x1 = xAt(edges[index + 1] ?? first + ((index + 1) * span) / counts.length)
        const barW = Math.max(2, (x1 - x0) * 0.76)
        const barX = x0 + (x1 - x0 - barW) / 2
        const barH = (count / maxCount) * plotH
        return (
          <rect
            key={`bar-${index}`}
            x={barX}
            y={top + plotH - barH}
            width={barW}
            height={count > 0 ? Math.max(barH, 1) : 0}
            rx="2"
            fill="#34d399"
            stroke="#34d399"
            strokeWidth="1"
          />
        )
      })}
      {xTicks.map((tick, index) => (
        <text key={`x-${index}`} x={xAt(tick)} y={top + plotH + 16} fill="#cbd5e1" fontSize="10" textAnchor="middle">
          {formatNumber(tick)}
        </text>
      ))}
      <text x={left + plotW / 2} y={height - 2} fill="#94a3b8" fontSize="10" textAnchor="middle">
        样本取值
      </text>
      <text
        x="10"
        y={top + plotH / 2}
        fill="#94a3b8"
        fontSize="10"
        textAnchor="middle"
        transform={`rotate(-90 10 ${top + plotH / 2})`}
      >
        频数
      </text>
    </svg>
  )
}

function ForestChart({ rows }: { rows: CiRow[] }) {
  const width = 640
  const rowH = 36
  const height = Math.max(160, 48 + rows.length * rowH)
  const left = 96
  const right = 24
  const top = 20
  const bottom = 36
  const plotW = width - left - right
  const lows = rows.map((row) => Math.min(row.low, row.center))
  const highs = rows.map((row) => Math.max(row.high, row.center))
  const min = Math.min(...lows)
  const max = Math.max(...highs)
  const pad = (max - min) * 0.1 || 1
  const domainMin = min - pad
  const domainMax = max + pad
  const xAt = (value: number) => left + ((value - domainMin) / (domainMax - domainMin)) * plotW
  const axisY = height - bottom
  const xTicks = Array.from({ length: 5 }, (_, index) => domainMin + (index / 4) * (domainMax - domainMin))

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="w-full" role="img" aria-label="置信区间森林图">
      {xTicks.map((tick, index) => (
        <g key={`tick-${index}`}>
          <line x1={xAt(tick)} y1={top - 8} x2={xAt(tick)} y2={axisY} stroke="#334155" strokeWidth="1" strokeDasharray="4 4" />
          <text x={xAt(tick)} y={axisY + 16} fill="#cbd5e1" fontSize="10" textAnchor="middle">
            {formatNumber(tick)}
          </text>
        </g>
      ))}
      <line x1={left} y1={axisY} x2={left + plotW} y2={axisY} stroke="#94a3b8" strokeWidth="1" />
      {rows.map((row, index) => {
        const y = top + index * rowH + rowH / 2
        const x0 = xAt(row.low)
        const x1 = xAt(row.high)
        const center = xAt(row.center)
        return (
          <g key={`${row.label}-${index}`}>
            <text x={8} y={y + 4} fill="#cbd5e1" fontSize="11">
              {row.label}
            </text>
            <line x1={x0} y1={y} x2={x1} y2={y} stroke="#60a5fa" strokeWidth="3" strokeLinecap="round" />
            <line x1={x0} y1={y - 5} x2={x0} y2={y + 5} stroke="#60a5fa" strokeWidth="2" />
            <line x1={x1} y1={y - 5} x2={x1} y2={y + 5} stroke="#60a5fa" strokeWidth="2" />
            <circle cx={center} cy={y} r="4" fill="#f87171" stroke="#fecaca" strokeWidth="1" />
          </g>
        )
      })}
      <text x={left + plotW / 2} y={height - 2} fill="#94a3b8" fontSize="10" textAnchor="middle">
        区间端点与中心取值
      </text>
    </svg>
  )
}

function SeedChart({ rows }: { rows: SeedRow[] }) {
  const width = 640
  const height = 240
  const left = 48
  const right = 16
  const top = 16
  const bottom = 40
  const plotW = width - left - right
  const plotH = height - top - bottom
  const values = rows.flatMap((row) => [row.mean - (row.std ?? 0), row.mean + (row.std ?? 0)])
  const min = Math.min(0, ...values)
  const max = Math.max(...values)
  const paddedMax = max === min ? min + 1 : max
  const yAt = (value: number) => top + plotH - ((value - min) / (paddedMax - min)) * plotH
  const slot = plotW / rows.length
  const barW = Math.min(56, slot * 0.55)
  const yTicks = [min, (min + paddedMax) / 2, paddedMax]

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="w-full" role="img" aria-label="各种子均值对比条形图">
      {yTicks.map((tick, index) => (
        <g key={`y-${index}`}>
          <line x1={left} y1={yAt(tick)} x2={left + plotW} y2={yAt(tick)} stroke="#334155" strokeWidth="1" strokeDasharray="4 4" />
          <text x={left - 6} y={yAt(tick) + 3} fill="#94a3b8" fontSize="10" textAnchor="end">
            {formatNumber(tick)}
          </text>
        </g>
      ))}
      <line x1={left} y1={yAt(min)} x2={left + plotW} y2={yAt(min)} stroke="#94a3b8" strokeWidth="1" />
      <line x1={left} y1={top} x2={left} y2={top + plotH} stroke="#94a3b8" strokeWidth="1" />
      {rows.map((row, index) => {
        const centerX = left + slot * (index + 0.5)
        const barY = yAt(Math.max(row.mean, min))
        const barH = Math.max(1, Math.abs(yAt(row.mean) - yAt(min)))
        const seedLabel = row.seed.length > 10 ? `${row.seed.slice(0, 9)}…` : row.seed
        return (
          <g key={`${row.seed}-${index}`}>
            <rect
              x={centerX - barW / 2}
              y={barY}
              width={barW}
              height={barH}
              rx="2"
              fill="#a78bfa"
              stroke="#a78bfa"
              strokeWidth="1"
            />
            {row.std !== null && (
              <line
                x1={centerX}
                y1={yAt(row.mean + row.std)}
                x2={centerX}
                y2={yAt(Math.max(0, row.mean - row.std))}
                stroke="#94a3b8"
                strokeWidth="2"
              />
            )}
            <text x={centerX} y={top + plotH + 16} fill="#cbd5e1" fontSize="10" textAnchor="middle">
              {seedLabel}
            </text>
          </g>
        )
      })}
      <text x={left + plotW / 2} y={height - 2} fill="#94a3b8" fontSize="10" textAnchor="middle">
        随机种子
      </text>
      <text
        x="10"
        y={top + plotH / 2}
        fill="#94a3b8"
        fontSize="10"
        textAnchor="middle"
        transform={`rotate(-90 10 ${top + plotH / 2})`}
      >
        均值
      </text>
    </svg>
  )
}

/* ------------------------------------------------------------------ 报告展示 */

function EvidenceBlock({ evidence }: { evidence: StatsEvidence }) {
  return (
    <div className="rounded-lg border border-slate-700 bg-navy-950/60 p-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="text-[11px] font-semibold text-slate-300">来源：{evidence.source || '输入'}</span>
        <span className="mono text-[10px] text-slate-500">{evidence.method || '未标注方法'}</span>
      </div>
      <div className="mt-2 grid gap-2 md:grid-cols-2">
        <div className="min-w-0">
          <p className="text-[11px] text-slate-400">报告值</p>
          <pre className="mono mt-1 max-h-40 overflow-auto rounded bg-slate-900/80 p-2 text-[10px] leading-4 text-slate-300">
            {formatJson(evidence.claimed)}
          </pre>
        </div>
        <div className="min-w-0">
          <p className="text-[11px] text-slate-400">重算值</p>
          <pre className="mono mt-1 max-h-40 overflow-auto rounded bg-slate-900/80 p-2 text-[10px] leading-4 text-slate-300">
            {formatJson(evidence.recomputed)}
          </pre>
        </div>
      </div>
      {evidence.formula && (
        <div className="mt-2">
          <p className="text-[11px] text-slate-400">计算公式</p>
          <p className="mono mt-1 break-all rounded bg-slate-900/80 p-2 text-[10px] leading-4 text-emerald-200">
            {evidence.formula}
          </p>
        </div>
      )}
      {evidence.inputs && Object.keys(evidence.inputs).length > 0 && (
        <div className="mt-2">
          <p className="text-[11px] text-slate-400">重算输入</p>
          <pre className="mono mt-1 max-h-40 overflow-auto rounded bg-slate-900/80 p-2 text-[10px] leading-4 text-slate-300">
            {formatJson(evidence.inputs)}
          </pre>
        </div>
      )}
      {evidence.note && <p className="mt-2 text-[11px] leading-5 text-slate-400">说明：{evidence.note}</p>}
    </div>
  )
}

function FindingCard({
  finding,
  index,
  open,
  onToggle,
}: {
  finding: StatsReport['findings'][number]
  index: number
  open: boolean
  onToggle: (key: string) => void
}) {
  const meta = VERDICT_META[finding.verdict] ?? VERDICT_META.verified
  const key = `${finding.rule_id}-${index}`
  return (
    <article className="rounded-lg border border-slate-700 bg-navy-900 p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex min-w-0 items-center gap-2">
          <span className="mono rounded bg-slate-700/60 px-2 py-0.5 text-[11px] text-slate-200">
            {finding.rule_id}
          </span>
          <span className="text-sm font-semibold text-slate-100">{finding.rule_name}</span>
        </div>
        <VerdictBadge verdict={finding.verdict} label={finding.verdict_label_zh || meta.label} />
      </div>
      <p className="mt-3 text-sm leading-6 text-slate-200">{finding.message}</p>
      <p className="mt-2 text-[11px] text-slate-400">
        分类：{finding.category} · 置信度：{finding.confidence} · 影响范围：{finding.affects}
      </p>
      {finding.justification && (
        <p className="mt-2 text-xs leading-5 text-slate-300">
          <span className="text-slate-400">判定依据：</span>
          {finding.justification}
        </p>
      )}
      <details className="group mt-3 rounded-lg border border-slate-700 bg-navy-800/60" open={open}>
        <summary
          className="flex cursor-pointer list-none items-center gap-1.5 px-3 py-2 text-xs font-semibold text-emerald-300"
          onClick={(event) => {
            event.preventDefault()
            onToggle(key)
          }}
        >
          <ChevronDown size={14} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
          证据明细（{finding.evidence.length} 条）
        </summary>
        <div className="space-y-3 border-t border-slate-700 p-3">
          {finding.evidence.length === 0 ? (
            <p className="text-xs text-slate-400">该发现未附带可复算证据。</p>
          ) : (
            finding.evidence.map((evidence, evidenceIndex) => (
              <EvidenceBlock key={`evidence-${evidenceIndex}`} evidence={evidence} />
            ))
          )}
        </div>
      </details>
      {finding.suggestion && (
        <p className="mt-3 text-xs leading-5 text-amber-200">
          <span className="text-amber-300/80">复核建议：</span>
          {finding.suggestion}
        </p>
      )}
      <div className="mt-3 flex items-center gap-1.5 text-[11px] text-slate-400">
        {finding.causal_language_checked ? (
          <ShieldCheck size={13} className="text-emerald-400" />
        ) : (
          <ShieldAlert size={13} className="text-amber-400" />
        )}
        表述守卫：{finding.causal_language_checked ? '通过，仅陈述统计事实' : '未通过，已转人工复核'}
      </div>
    </article>
  )
}

function ReportView({
  report,
  histogram,
  ciRows,
  seedRows,
  openEvidence,
  onToggleEvidence,
}: {
  report: StatsReport
  histogram: HistogramData | null
  ciRows: CiRow[]
  seedRows: SeedRow[]
  openEvidence: Record<string, boolean>
  onToggleEvidence: (key: string) => void
}) {
  const scopeKeys = Array.isArray(report.scope.input_keys)
    ? report.scope.input_keys.map((item) => String(item))
    : []
  return (
    <div className="flex flex-col gap-5">
      <section className="rounded-xl border border-slate-700 bg-navy-800 p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs text-slate-400">
              报告编号 <span className="mono text-slate-200">{report.report_id}</span>
            </p>
            <p className="mt-1 text-xs text-slate-400">
              生成时间：{formatTime(report.created_at)} · 版本：{report.version}
            </p>
            {scopeKeys.length > 0 && (
              <p className="mt-1 text-xs text-slate-400">审计范围：{scopeKeys.join('、')}</p>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-full border border-red-400/60 bg-red-400/10 px-3 py-1 text-xs font-semibold text-red-300">
              阻断项 {report.blocking_count}
            </span>
            <span className="rounded-full border border-slate-600 bg-slate-700/40 px-3 py-1 text-xs font-semibold text-slate-300">
              发现 {report.findings.length} 条
            </span>
          </div>
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
          {VERDICT_ORDER.map((verdict) => (
            <div key={verdict} className="rounded-lg border border-slate-700 bg-navy-900 p-3">
              <p className="text-[11px] text-slate-400">{VERDICT_META[verdict].hint}</p>
              <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
                <VerdictBadge verdict={verdict} />
                <span
                  className="mono text-xl font-semibold"
                  style={{ color: VERDICT_META[verdict].color }}
                >
                  {report.counts[verdict] ?? 0}
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="rounded-xl border border-slate-700 bg-navy-800 p-5">
        <h3 className="text-sm font-semibold text-slate-100">审计发现</h3>
        <p className="mt-1 text-xs text-slate-400">每条发现均可展开证据，核对报告值、重算值、公式与输入。</p>
        {report.findings.length === 0 ? (
          <div className={STATE_OVERRIDE}>
            <EmptyState title="暂无发现" description="本次输入未产生审计发现。" compact />
          </div>
        ) : (
          <div className="mt-4 flex flex-col gap-3">
            {report.findings.map((finding, index) => (
              <FindingCard
                key={`${finding.rule_id}-${index}`}
                finding={finding}
                index={index}
                open={Boolean(openEvidence[`${finding.rule_id}-${index}`])}
                onToggle={onToggleEvidence}
              />
            ))}
          </div>
        )}
      </section>

      <section className="rounded-xl border border-slate-700 bg-navy-800 p-5">
        <div className="mb-4 flex items-center gap-2">
          <Activity size={16} className="text-emerald-300" />
          <h3 className="text-sm font-semibold text-slate-100">可复算数据可视化</h3>
        </div>
        <div className="grid gap-4 xl:grid-cols-2">
          <ChartPanel
            title="样本分布直方图"
            hint={histogram ? `数据来源：${histogram.source}` : '来自分布数据的分箱计数'}
            legend={[{ color: '#34d399', label: '频数', shape: 'bar' }]}
            empty={!histogram}
          >
            {histogram && <HistogramChart data={histogram} />}
          </ChartPanel>
          <ChartPanel
            title="置信区间森林图"
            hint="蓝色线段为区间，红色圆点为中心取值"
            legend={[
              { color: '#60a5fa', label: '区间', shape: 'line' },
              { color: '#f87171', label: '中心值', shape: 'dot' },
            ]}
            empty={ciRows.length === 0}
          >
            <ForestChart rows={ciRows} />
          </ChartPanel>
          <ChartPanel
            title="随机种子均值对比"
            hint="灰色细线表示组内标准差；缺失则不绘制"
            legend={[
              { color: '#a78bfa', label: '各种子均值', shape: 'bar' },
              { color: '#94a3b8', label: '组内标准差', shape: 'line' },
            ]}
            empty={seedRows.length === 0}
          >
            <SeedChart rows={seedRows} />
          </ChartPanel>
        </div>
      </section>

      <section className="rounded-xl border border-amber-500/40 bg-amber-500/5 p-5">
        <div className="flex items-center gap-2">
          <ShieldAlert size={16} className="text-amber-300" />
          <h3 className="text-sm font-semibold text-amber-100">边界声明与未验证项</h3>
        </div>
        <ul className="mt-3 list-disc space-y-1.5 pl-5 text-xs leading-5 text-amber-100/80">
          {report.limitations.map((item, index) => (
            <li key={`limitation-${index}`}>{item}</li>
          ))}
        </ul>
      </section>
    </div>
  )
}

function ComputeResultView({
  result,
  operation,
}: {
  result: StatsComputeResult
  operation: string
}) {
  const values = asRecord(result.values) ?? {}
  return (
    <section className="rounded-xl border border-slate-700 bg-navy-800 p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h3 className="text-sm font-semibold text-slate-100">计算结果</h3>
        <span
          className="rounded-full border px-2.5 py-0.5 text-[11px] font-semibold"
          style={{
            color: result.supported ? '#34d399' : '#fbbf24',
            borderColor: result.supported ? '#34d399' : '#fbbf24',
            backgroundColor: result.supported ? '#34d3991f' : '#fbbf241f',
          }}
        >
          {result.supported ? '计算完成' : '未计算'}
        </span>
      </div>
      <p className="mt-2 text-xs text-slate-400">
        原语：<span className="mono text-slate-200">{operation}</span>
        {result.method ? ` · 方法：${result.method}` : ''}
      </p>
      <div className="mt-4 grid gap-3 md:grid-cols-2">
        <div className="rounded-lg border border-slate-700 bg-navy-950 p-3">
          <p className="text-[11px] text-slate-400">主结果</p>
          <pre className="mono mt-1 max-h-48 overflow-auto text-xs leading-5 text-emerald-200">
            {formatJson(result.value ?? null)}
          </pre>
        </div>
        <div className="rounded-lg border border-slate-700 bg-navy-950 p-3">
          <p className="text-[11px] text-slate-400">附加数值</p>
          <pre className="mono mt-1 max-h-48 overflow-auto text-xs leading-5 text-slate-200">
            {formatJson(values)}
          </pre>
        </div>
      </div>
      <div className="mt-3 rounded-lg border border-slate-700 bg-navy-950 p-3">
        <p className="text-[11px] text-slate-400">计算公式</p>
        <p className="mono mt-1 break-all text-xs leading-5 text-slate-200">
          {result.formula || '该原语未提供公式。'}
        </p>
      </div>
      <div className="mt-3 grid gap-3 md:grid-cols-2">
        <div className="rounded-lg border border-slate-700 bg-navy-950 p-3">
          <p className="text-[11px] text-slate-400">重算输入</p>
          <pre className="mono mt-1 max-h-40 overflow-auto text-[11px] leading-5 text-slate-300">
            {formatJson(result.inputs)}
          </pre>
        </div>
        <div className="rounded-lg border border-slate-700 bg-navy-950 p-3">
          <p className="text-[11px] text-slate-400">说明</p>
          <p className="mt-1 text-xs leading-5 text-slate-300">
            {result.note || '该原语未提供额外说明。'}
          </p>
        </div>
      </div>
      {!result.supported && (
        <p className="mt-3 rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-xs leading-5 text-amber-200">
          当前参数下未返回可用数值，请核对参数后重试；不会补造结果。
        </p>
      )}
    </section>
  )
}

/* ------------------------------------------------------------------ 页面主体 */

export default function StatsAuditPage() {
  const [mode, setMode] = useState<Mode>('full')
  const [auditInput, setAuditInput] = useState(SAMPLE_JSON)
  const [kwargsInput, setKwargsInput] = useState(DEFAULT_KWARGS)
  const [operation, setOperation] = useState('mean')
  const [openEvidence, setOpenEvidence] = useState<Record<string, boolean>>({})

  const catalogQuery = useQuery({
    queryKey: ['stats-audit', 'catalog'],
    queryFn: statsApi.catalog,
    retry: 1,
  })
  const operations = useMemo(() => {
    const fromCatalog = catalogQuery.data?.operations ?? []
    return fromCatalog.length > 0 ? fromCatalog : FALLBACK_OPERATIONS
  }, [catalogQuery.data])
  const selectedOperation = operations.includes(operation) ? operation : operations[0] ?? 'mean'

  const auditMutation = useMutation({
    mutationFn: () => statsApi.run(parseObject(auditInput, '实验统计输入')),
    onError: (error) => toast.error(`运行审计失败：${errorMessage(error)}`),
  })
  const computeMutation = useMutation({
    mutationFn: () => statsApi.compute(selectedOperation, parseObject(kwargsInput, '计算参数')),
    onError: (error) => toast.error(`计算失败：${errorMessage(error)}`),
  })

  const report = auditMutation.data
  const histogram = useMemo(() => (report ? collectHistogram(report) : null), [report])
  const ciRows = useMemo(() => (report ? collectCiRows(report) : []), [report])
  const seedRows = useMemo(() => (report ? collectSeedRows(report) : []), [report])

  const toggleEvidence = (key: string) => {
    setOpenEvidence((previous) => ({ ...previous, [key]: !previous[key] }))
  }

  return (
    <div className="min-h-screen bg-navy-950 px-5 py-6 text-slate-100">
      <div className="mx-auto flex max-w-7xl flex-col gap-5">
        <div className={STATE_OVERRIDE}>
          <PageHeader
            title="统计学审计"
            description="检查实验结果是否有合理的统计支撑（不替代人工判断）"
          />
        </div>

        <div className="inline-flex w-fit flex-wrap gap-1 rounded-xl border border-slate-700 bg-navy-800 p-1" role="tablist">
          <button
            type="button"
            role="tab"
            aria-selected={mode === 'full'}
            onClick={() => setMode('full')}
            className={`inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition ${
              mode === 'full' ? 'bg-emerald-500/20 text-emerald-200' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FlaskConical size={15} />
            完整审计
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={mode === 'compute'}
            onClick={() => setMode('compute')}
            className={`inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition ${
              mode === 'compute' ? 'bg-emerald-500/20 text-emerald-200' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Calculator size={15} />
            单原语计算
          </button>
        </div>

        {mode === 'full' ? (
          <>
            <section className="rounded-xl border border-slate-700 bg-navy-800 p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h3 className="text-sm font-semibold text-slate-100">完整审计输入</h3>
                  <p className="mt-1 text-xs text-slate-400">
                    填写实验统计 JSON；缺失字段记为证据不足，不补造数值。
                  </p>
                </div>
                <button type="button" className={SECONDARY_BTN} onClick={() => setAuditInput(SAMPLE_JSON)}>
                  <RotateCcw size={14} />
                  载入示例
                </button>
              </div>
              <label htmlFor="stats-audit-input" className="field-label mt-4 !text-slate-300">
                实验统计 JSON
              </label>
              <textarea
                id="stats-audit-input"
                value={auditInput}
                onChange={(event) => setAuditInput(event.target.value)}
                rows={14}
                spellCheck={false}
                className={TEXTAREA_CLS}
              />
              <div className="mt-3 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  className={PRIMARY_BTN}
                  disabled={auditMutation.isPending}
                  onClick={() => auditMutation.mutate()}
                >
                  {auditMutation.isPending ? (
                    <Loader2 size={15} className="animate-spin" />
                  ) : (
                    <Play size={15} />
                  )}
                  {auditMutation.isPending ? '审计中…' : '运行审计'}
                </button>
                <span className="text-xs text-slate-400">
                  示例含多次运行、种子分数、两组样本、p 值与指标声称。
                </span>
              </div>
            </section>

            {auditMutation.isPending && (
              <div className={STATE_OVERRIDE}>
                <LoadingState message="正在执行统计审计…" hint="全部为可复算的确定性计算，不调用模型。" compact />
              </div>
            )}
            {auditMutation.isError && (
              <div className={STATE_OVERRIDE}>
                <ErrorState
                  message={errorMessage(auditMutation.error)}
                  code={errorCode(auditMutation.error)}
                  onRetry={() => auditMutation.mutate()}
                  compact
                />
              </div>
            )}
            {report && (
              <ReportView
                report={report}
                histogram={histogram}
                ciRows={ciRows}
                seedRows={seedRows}
                openEvidence={openEvidence}
                onToggleEvidence={toggleEvidence}
              />
            )}
            {!report && !auditMutation.isPending && !auditMutation.isError && (
              <div className={STATE_OVERRIDE}>
                <EmptyState
                  title="暂无审计结果"
                  description="载入示例或填写实验统计 JSON 后，点击「运行审计」查看六类可信度结果。"
                  compact
                />
              </div>
            )}
          </>
        ) : (
          <>
            <section className="rounded-xl border border-slate-700 bg-navy-800 p-5">
              <div>
                <h3 className="text-sm font-semibold text-slate-100">单原语计算</h3>
                <p className="mt-1 text-xs text-slate-400">
                  返回数值、公式与重算输入，便于独立复核。
                </p>
              </div>
              <div className="mt-4 grid gap-4 lg:grid-cols-[220px_1fr]">
                <div className="min-w-0">
                  <label htmlFor="stats-operation" className="field-label !text-slate-300">
                    计算原语
                  </label>
                  <select
                    id="stats-operation"
                    value={selectedOperation}
                    onChange={(event) => setOperation(event.target.value)}
                    className="field-input !border-slate-700 !bg-navy-950 !text-slate-200"
                  >
                    {operations.map((item) => (
                      <option key={item} value={item}>
                        {item}
                      </option>
                    ))}
                  </select>
                  {catalogQuery.isError && (
                    <p className="mt-2 text-[11px] text-amber-300">目录加载失败，已显示常用原语。</p>
                  )}
                  <p className="mt-2 text-[11px] text-slate-400">
                    目录版本：{catalogQuery.data?.version ?? '未加载'}
                  </p>
                </div>
                <div className="min-w-0">
                  <label htmlFor="stats-kwargs" className="field-label !text-slate-300">
                    参数 JSON
                  </label>
                  <textarea
                    id="stats-kwargs"
                    value={kwargsInput}
                    onChange={(event) => setKwargsInput(event.target.value)}
                    rows={10}
                    spellCheck={false}
                    className={TEXTAREA_CLS}
                  />
                  <p className="mt-2 text-[11px] text-slate-400">
                    不同原语参数不同：均值使用样本数组，检验使用两组样本，种子分析使用分组分数。
                  </p>
                </div>
              </div>
              <div className="mt-3 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  className={PRIMARY_BTN}
                  disabled={computeMutation.isPending}
                  onClick={() => computeMutation.mutate()}
                >
                  {computeMutation.isPending ? (
                    <Loader2 size={15} className="animate-spin" />
                  ) : (
                    <Play size={15} />
                  )}
                  {computeMutation.isPending ? '计算中…' : '计算'}
                </button>
              </div>
            </section>

            {catalogQuery.isPending && (
              <div className={STATE_OVERRIDE}>
                <LoadingState message="正在加载原语目录…" compact />
              </div>
            )}
            {computeMutation.isPending && (
              <div className={STATE_OVERRIDE}>
                <LoadingState message="正在执行计算…" compact />
              </div>
            )}
            {computeMutation.isError && (
              <div className={STATE_OVERRIDE}>
                <ErrorState
                  message={errorMessage(computeMutation.error)}
                  code={errorCode(computeMutation.error)}
                  onRetry={() => computeMutation.mutate()}
                  compact
                />
              </div>
            )}
            {computeMutation.data && (
              <ComputeResultView result={computeMutation.data} operation={selectedOperation} />
            )}
            {!computeMutation.data && !computeMutation.isPending && !computeMutation.isError && (
              <div className={STATE_OVERRIDE}>
                <EmptyState
                  title="暂无计算结果"
                  description="选择计算原语并填写参数 JSON 后，点击「计算」查看可复算数值。"
                  compact
                />
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}
